# Earlier CPU timing notes

The raw repeats for these two short checks were reported in the conversation as summaries.

- ROI, raw LSD, collinear merging and right-corner pairing were timed on 23 archived units, excluding B2.1. Medians were 2.62, 1.23, 4.58 and 11.01 ms respectively. Combined preparation with ROI was 3.81 ms for local fitting and 19.29 ms for full fitting, with P90 at 6.11 and 30.02 ms. Search and scoring were outside this timing.
- Earlier four-round versus six-round check, B5.1 at a half-short-side offset. Direct full search took about 72.1 ms, four-round local then full took 114.2 ms, and reaching the solution in up to six local rounds took 35.8 ms. This example was selected because the four-round run failed locally.
