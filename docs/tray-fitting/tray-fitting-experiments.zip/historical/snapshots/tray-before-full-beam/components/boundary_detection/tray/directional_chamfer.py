"""Local rectangle proposals on direction-aware distances to observed edges."""

import cv2
import numpy as np

from ..geometry import rectangle_corners


_STEPS = tuple((x, y) for x in (-1, 0, 1) for y in (-1, 0, 1))
_FRACTIONS = np.linspace(0.03, 0.97, 24)[None, :, None]
_SIDE_ANGLES = np.array([0, np.pi / 2, 0, np.pi / 2])
_DIRECTION_COUNT = 36  # Undirected tangents, one bin per 5 degrees.


def _distance_fields(lines, shape):
    delta = lines[:, 2:] - lines[:, :2]
    angle_step = np.pi / _DIRECTION_COUNT
    bins = np.rint(np.arctan2(delta[:, 1], delta[:, 0]) / angle_step).astype(int) % _DIRECTION_COUNT
    occupied = np.unique(bins)
    fields = np.empty((len(occupied), *shape), dtype=np.float32)
    for index, direction in enumerate(occupied):
        raster = np.ones(shape, dtype=np.uint8)
        for ax, ay, bx, by in np.rint(lines[bins == direction] * 16).astype(int):
            cv2.line(raster, (ax, ay), (bx, by), 0, 1, shift=4)
        cv2.distanceTransform(raster, cv2.DIST_L2, cv2.DIST_MASK_5, fields[index])
    return fields, occupied * angle_step


def beam_pose(view, lines, center, angle, tolerance, angle_tolerance):
    """Return a better coarse center and angle near the previous accepted pose."""
    if not len(lines):
        return None

    height, width = view["mask"].shape
    fields, orientations = _distance_fields(lines, (height, width))
    step = max(1.0, float(min(view["size"])) * 0.10)
    costs = {}

    def evaluate(states):
        grid = np.asarray(states)
        for slot in np.unique(grid[:, 2]):
            group = grid[grid[:, 2] == slot]
            theta = angle + np.radians(4 * slot)
            polygon = rectangle_corners(np.zeros(2), theta, view["size"])
            sides = np.roll(polygon, -1, axis=0) - polygon
            samples = polygon[:, None, :] + _FRACTIONS * sides[:, None, :]
            positions = center + group[:, :2] * step
            lower = -polygon.min(axis=0)
            upper = np.array([width - 1, height - 1]) - polygon.max(axis=0)
            valid = ((positions >= lower) & (positions <= upper)).all(axis=1)

            pixels = np.rint(positions[:, None, None, :] + samples).astype(int)
            x = np.clip(pixels[..., 0], 0, width - 1)
            y = np.clip(pixels[..., 1], 0, height - 1)
            difference = np.abs(orientations[:, None] - (theta + _SIDE_ANGLES) % np.pi)
            angular_cost = np.minimum(difference, np.pi - difference) * (tolerance / angle_tolerance)
            distance = fields[:, y, x]
            # Minimize the distance and angular cost jointly over observed orientation bins.
            distance += angular_cost[:, None, :, None].astype(np.float32)
            cost = np.minimum(distance.min(axis=0), 3 * tolerance).mean(axis=(1, 2))
            costs.update(zip(map(tuple, group), np.where(valid, cost, np.inf)))

    origin = (0, 0, 0)
    beam = [origin]
    evaluate(beam)
    best_cost = costs[origin]
    for round_index in range(4):
        frontier = set(beam)
        for x, y, slot in beam:
            slots = range(-3, 4) if round_index == 0 else range(max(-3, slot - 1), min(3, slot + 1) + 1)
            frontier.update((x + dx, y + dy, neighbor) for neighbor in slots for dx, dy in _STEPS)
        fresh = sorted(frontier.difference(costs))
        if not fresh:
            break
        evaluate(fresh)
        beam = sorted(frontier, key=lambda state: (
            costs[state], state[0] ** 2 + state[1] ** 2, abs(state[2]), state))[:3]
        current_cost = costs[beam[0]]
        if current_cost >= best_cost - 0.02 * tolerance:
            break
        best_cost = current_cost

    if beam[0] == origin or not np.isfinite(costs[beam[0]]):
        return None
    x, y, slot = beam[0]
    return center + np.array([x, y]) * step, angle + np.radians(4 * slot)
