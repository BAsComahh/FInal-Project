"""Corner, single-edge and mask-search proposals for a known-size tray."""

from dataclasses import asdict, dataclass
import heapq

import numpy as np

from ..lsd import detect_lsd_lines
from ..merge import merge_collinear_segments
from ..geometry import line_intersection, rectangle_corners as rectangle
from ..scale import percent_to_length
from components.homography.geometry import transform_points
from .geometry import make_work_view
from .directional_chamfer import DirectionalChamfer, beam_pose


@dataclass
class TrayConfig:
    mode: str = "auto"
    merge: bool = True
    max_work_size: int = 512
    roi_margin_pct: float = 25
    min_line_length_pct: float = 12
    angle_tolerance_deg: float = 12
    endpoint_gap_pct: float = 18
    edge_tolerance_pct: float = 2.5
    merge_distance_pct: float = 2.5
    merge_gap_pct: float = 30
    corner_dedup_pct: float = 3
    corner_nudge_pct: float = 1
    candidate_dedup_pct: float = 1.5
    max_lines: int = 64
    max_corners: int = 16
    angle_step_deg: float = 5
    search_pct: float = 35
    refine_rounds: int = 3
    min_mask_coverage: float = 0.55
    min_corner_edge_support: float = 0.40
    min_single_edge_support: float = 0.20
    top_k: int = 5

    def validate(self):
        if self.mode not in ("auto", "corner", "edge", "mask"):
            raise ValueError("mode must be auto, corner, edge or mask")
        for key in ("roi_margin_pct", "min_line_length_pct", "endpoint_gap_pct", "edge_tolerance_pct",
                    "merge_distance_pct", "merge_gap_pct", "corner_dedup_pct", "corner_nudge_pct",
                    "candidate_dedup_pct", "search_pct"):
            percent_to_length(getattr(self, key), 1, name=key)
        if not 0 < self.angle_tolerance_deg < 45 or not 0 < self.angle_step_deg <= 45:
            raise ValueError("Angle tolerance must be in (0,45); angle step in (0,45]")
        for key in ("min_mask_coverage", "min_corner_edge_support", "min_single_edge_support"):
            if not 0 <= getattr(self, key) <= 1:
                raise ValueError(f"{key} must be in [0,1]")
        for key in ("max_work_size", "max_lines", "max_corners", "top_k"):
            value = getattr(self, key)
            if isinstance(value, bool) or int(value) != value or value < (32 if key == "max_work_size" else 1):
                raise ValueError(f"Invalid {key}")
        if isinstance(self.refine_rounds, bool) or int(self.refine_rounds) != self.refine_rounds or self.refine_rounds < 0:
            raise ValueError("refine_rounds must be a non-negative integer")


def _work_lengths(size, config):
    short_side = float(min(size))
    lengths = {name: percent_to_length(getattr(config, f"{name}_pct"), short_side, name=f"{name}_pct")
               for name in ("min_line_length", "endpoint_gap", "edge_tolerance", "merge_distance", "merge_gap",
                            "corner_dedup", "corner_nudge", "candidate_dedup")}
    lengths["search_width"] = percent_to_length(config.search_pct, float(size[0]), name="search_pct")
    lengths["search_depth"] = percent_to_length(config.search_pct, float(size[1]), name="search_pct")
    return lengths


def _line_pool(view, config, lengths, *, merge=True):
    raw = detect_lsd_lines(view["image"], blur_size=3)
    length = np.linalg.norm(raw[:, 2:] - raw[:, :2], axis=1)
    midpoint = np.rint((raw[:, :2] + raw[:, 2:]) / 2).astype(int)
    inside = view["valid"][midpoint[:, 1], midpoint[:, 0]] != 0
    raw = raw[inside & (length >= lengths["min_line_length"])]
    length = np.linalg.norm(raw[:, 2:] - raw[:, :2], axis=1)
    raw = raw[np.argsort(-length, kind="stable")[:config.max_lines * 2]].astype(float)
    return raw, _merged_pool(raw, config, lengths) if merge else raw[:config.max_lines]


def _merged_pool(raw, config, lengths):
    pool = raw.copy()
    if config.merge and len(raw):
        groups = merge_collinear_segments(raw, min_segment_length=lengths["min_line_length"],
                                          check_source_length=False, check_axis=False,
                                          distance_tolerance=lengths["merge_distance"],
                                          max_gap=lengths["merge_gap"], min_coverage=0.5)
        if groups:
            pool = np.vstack((pool, [group["line"] for group in groups]))
    length = np.linalg.norm(pool[:, 2:] - pool[:, :2], axis=1)
    # Preserve rotated local edges; do not reuse table-border axis/region filters.
    return pool[np.argsort(-length, kind="stable")[:config.max_lines]]


def _corners(lines, config, shape, lengths):
    found = []
    tolerance = lengths["endpoint_gap"]
    for i, a in enumerate(lines):
        u = a[2:] - a[:2]
        u = u / np.linalg.norm(u)
        for j in range(i + 1, len(lines)):
            b = lines[j]
            v = b[2:] - b[:2]
            v = v / np.linalg.norm(v)
            if abs(u @ v) > np.sin(np.radians(config.angle_tolerance_deg)):
                continue
            point = line_intersection(a, b)
            if point is None or not (0 <= point[0] < shape[1] and 0 <= point[1] < shape[0]):
                continue
            gaps = [np.linalg.norm(line.reshape(2, 2) - point, axis=1).min() for line in (a, b)]
            if max(gaps) > tolerance:
                continue
            rays = [line.reshape(2, 2)[np.argmax(np.linalg.norm(line.reshape(2, 2) - point, axis=1))] - point
                    for line in (a, b)]
            rays = [ray / np.linalg.norm(ray) for ray in rays]
            strength = (sum(np.linalg.norm(line[2:] - line[:2]) for line in (a, b))
                        / (lengths["corner_nudge"] + sum(gaps)))
            found.append({"point": point, "rays": rays, "line_indices": [i, j], "strength": float(strength)})
    found.sort(key=lambda item: -item["strength"])
    unique = []
    for item in found:
        if not any(np.linalg.norm(item["point"] - old["point"]) < lengths["corner_dedup"]
                   and abs(item["rays"][0] @ old["rays"][0]) > 0.97 for old in unique):
            unique.append(item)
        if len(unique) >= config.max_corners:
            break
    return unique


class _Scorer:
    def __init__(self, view, raw, image_shape, config, lengths):
        self.view, self.config, self.image_shape = view, config, image_shape
        self.thresholds = lengths
        ys, xs = np.nonzero(view["mask"])
        self.all_points = np.column_stack((xs, ys)).astype(float)
        indices = np.linspace(0, len(xs) - 1, min(4096, len(xs))).astype(int)
        self.points = self.all_points[indices]
        self.center = self.all_points.mean(axis=0)
        self.raw = raw
        delta = raw[:, 2:] - raw[:, :2]
        self.lengths = np.linalg.norm(delta, axis=1)
        self.directions = delta / np.maximum(self.lengths[:, None], 1e-9)
        self.tolerance = lengths["edge_tolerance"]
        self.mask_area = len(self.all_points)
        self.area = float(np.prod(view["size"]))
        self._chamfer = None

    @property
    def chamfer(self):
        if self._chamfer is None:
            self._chamfer = DirectionalChamfer(self.view, self.raw, self.tolerance,
                                               np.radians(self.config.angle_tolerance_deg))
        return self._chamfer

    def mask_scores(self, center, angle, points):
        delta = points - center
        u = np.array([np.cos(angle), np.sin(angle)])
        v = np.array([-u[1], u[0]])
        coverage = float(((np.abs(delta @ u) <= self.view["size"][0] / 2)
                          & (np.abs(delta @ v) <= self.view["size"][1] / 2)).mean())
        intersection = min(coverage * self.mask_area, self.area)
        iou = intersection / max(1, self.mask_area + self.area - intersection)
        return coverage, iou

    def coarse_score(self, center, angle, method):
        if self.polygons(center, angle) is None:
            return -np.inf
        coverage, iou = self.mask_scores(center, angle, self.points[::4])
        if method == "mask":
            return 0.8 * coverage + 0.2 * iou
        distance = self.chamfer.distances(np.asarray([center]), angle)[0]
        support = float(np.exp(-0.5 * (distance / self.tolerance) ** 2).mean())
        return 0.55 * support + 0.35 * coverage + 0.10 * iou

    def polygons(self, center, angle):
        polygon = rectangle(center, angle, self.view["size"])
        height, width = self.view["mask"].shape
        if ((polygon < -1e-6).any() or (polygon[:, 0] > width - 1 + 1e-6).any() or (polygon[:, 1] > height - 1 + 1e-6).any()):
            return None
        image_polygon = transform_points(polygon, self.view["work_to_image"])
        if ((image_polygon < -1e-6).any() or (image_polygon[:, 0] > self.image_shape[1] - 1 + 1e-6).any()
                or (image_polygon[:, 1] > self.image_shape[0] - 1 + 1e-6).any()):
            return None
        return polygon, image_polygon

    def score(self, proposal, method, *, exact=False):
        center, angle, provenance = proposal
        polygons = self.polygons(center, angle)
        if polygons is None:
            return None
        polygon, image_polygon = polygons
        coverage, iou = self.mask_scores(center, angle, self.all_points if exact else self.points)
        support = [0.0] * 4
        if exact or method != "mask":
            for index, (a, b) in enumerate(zip(polygon, np.roll(polygon, -1, axis=0))):
                direction = (b - a) / np.linalg.norm(b - a)
                aligned = np.abs(self.directions @ direction) >= np.cos(np.radians(self.config.angle_tolerance_deg))
                lines = self.raw[aligned]
                if not len(lines):
                    continue
                samples = a + np.linspace(0.03, 0.97, 24)[:, None] * (b - a)
                line_delta = lines[:, 2:] - lines[:, :2]
                offset = samples[:, None] - lines[None, :, :2]
                t = np.clip((offset * line_delta).sum(axis=2) / (line_delta ** 2).sum(axis=1), 0, 1)
                nearest = lines[None, :, :2] + t[:, :, None] * line_delta
                distances = np.linalg.norm(samples[:, None] - nearest, axis=2).min(axis=1)
                support[index] = float(np.exp(-0.5 * (distances / self.tolerance) ** 2).mean())
        edge_support = float(np.mean(support))
        score = (0.8 * coverage + 0.2 * iou if method == "mask" else
                 0.55 * edge_support + 0.35 * coverage + 0.10 * iou)
        return {"method": method, "score": float(score), "mask_coverage": coverage, "mask_iou": float(iou),
                "edge_support": edge_support, "edge_support_per_side": support,
                "center_work": np.asarray(center).tolist(), "angle_deg": float(np.degrees(angle) % 180),
                "corners_work": polygon.tolist(), "corners_image": image_polygon.tolist(),
                "corners_plane": transform_points(polygon, self.view["work_to_plane"]).tolist(),
                "center_plane": transform_points(center, self.view["work_to_plane"]).tolist(),
                "provenance": provenance}


def _corner_proposals(corners, size):
    for index, item in enumerate(corners):
        rays = (item["rays"],) if size[0] == size[1] else (item["rays"], item["rays"][::-1])
        for first, second in rays:
            angle = np.arctan2(first[1], first[0])
            side = 1 if first[0] * second[1] - first[1] * second[0] > 0 else -1
            across = np.array([-first[1], first[0]]) * side
            center = item["point"] + first * size[0] / 2 + across * size[1] / 2
            yield center, angle, {"corner_index": index}


def _local_proposals(center, angle, lengths, provenance):
    for dx in (-2, 0, 2):
        for dy in (-2, 0, 2):
            for degrees in (-2, 0, 2):
                yield (center + np.array([dx, dy]) * lengths["corner_nudge"],
                       angle + np.radians(degrees), provenance)


def _edge_seeds(lines, size, mask_center):
    for index, line in enumerate(lines[:12]):
        u = (line[2:] - line[:2]) / np.linalg.norm(line[2:] - line[:2])
        normal = np.array([-u[1], u[0]])
        on_line = line[:2] + u * ((mask_center - line[:2]) @ u)
        swaps = (False,) if size[0] == size[1] else (False, True)
        for swap in swaps:
            along, across = size[::-1] if swap else size
            angle = np.arctan2(u[1], u[0]) + (np.pi / 2 if swap else 0)
            for side in (-1, 1):
                center = on_line + normal * side * across / 2
                yield center, angle, u * along, {"line_index": index, "search": "edge_beam"}


def _search_beam(seeds, advance, score, rounds):
    costs = {}
    beam = []
    frontier = set(seeds)
    for round_index in range(rounds + 1):
        for state in sorted(frontier.difference(costs)):
            costs[state] = score(state)
        beam = sorted(frontier, key=lambda state: (-costs[state], state))[:3]
        frontier = set(beam)
        if round_index < rounds:
            frontier.update(neighbor for state in beam for neighbor in advance(state, round_index))
    return [state for state in beam if np.isfinite(costs[state])], len(costs)


def _edge_beam(scorer, lines, rounds):
    seeds = list(_edge_seeds(lines, scorer.view["size"], scorer.center))

    def proposal(state):
        index, offset = state
        center, angle, along, provenance = seeds[index]
        return center + along * offset, angle, provenance

    def advance(state, round_index):
        index, offset = state
        step = 0.2 / 2 ** round_index
        return [(index, round(offset - step, 10)), (index, round(offset + step, 10))]

    def score(state):
        center, angle, _ = proposal(state)
        return scorer.coarse_score(center, angle, "edge")

    beam, count = _search_beam(((index, 0.0) for index in range(len(seeds))), advance, score, rounds)
    return [proposal(state) for state in beam], count


def _mask_beam(scorer, centers, config):
    angles = np.arange(0, 90 if scorer.view["size"][0] == scorer.view["size"][1] else 180,
                       config.angle_step_deg)
    search = np.array([scorer.thresholds["search_width"], scorer.thresholds["search_depth"]])
    moves = ((-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1))

    def advance(state, round_index):
        x, y, degrees = state
        dx, dy = search / 2 ** (round_index + 1)
        angle_step = config.angle_step_deg / 2 ** (round_index + 1)
        for u, v in moves:
            yield round(x + u * dx, 8), round(y + v * dy, 8), degrees
        for direction in (-1, 1):
            yield x, y, round((degrees + direction * angle_step) % 180, 8)

    def score(state):
        x, y, degrees = state
        return scorer.coarse_score(np.array([x, y]), np.radians(degrees), "mask")

    initial = ((round(x, 8), round(y, 8), round(degrees, 8)) for x, y in centers for degrees in angles)
    beam, count = _search_beam(initial, advance, score, int(config.refine_rounds))
    return [(np.array([x, y]), np.radians(degrees), {"search": "mask_beam"}) for x, y, degrees in beam], count


def _rank(proposals, method, scorer, config):
    heap, count = [], 0

    def offer(item, serial):
        entry = (item["score"], serial, item)
        if len(heap) < max(20, config.top_k * 4):
            heapq.heappush(heap, entry)
        elif entry[:2] > heap[0][:2]:
            heapq.heapreplace(heap, entry)

    for index, proposal in enumerate(proposals):
        item = scorer.score(proposal, method)
        if item is None:
            continue
        count += 1
        offer(item, index)
    ranked = []
    for _, _, item in heap:
        proposal = (np.asarray(item["center_work"]), np.radians(item["angle_deg"]), item["provenance"])
        exact_item = scorer.score(proposal, method, exact=True)
        if exact_item is not None:
            ranked.append(exact_item)
    ranked.sort(key=lambda item: -item["score"])
    unique = []
    for item in ranked:
        if not any(np.linalg.norm(np.asarray(item["center_work"]) - old["center_work"]) < scorer.thresholds["candidate_dedup"]
                   and abs(((item["angle_deg"] - old["angle_deg"] + 90) % 180) - 90) < 2 for old in unique):
            unique.append(item)
        if len(unique) >= config.top_k:
            break
    return count, unique


def _accepted_candidate(top, min_mask_coverage, min_edge_support):
    return next((item for item in top if item["mask_coverage"] >= min_mask_coverage
                 and item["edge_support"] >= min_edge_support), None)


def _rank_local(corners, scorer, config):
    points = transform_points(corners, scorer.view["image_to_work"])
    center = points.mean(axis=0)
    axis = points[1] - points[0]
    angle = np.arctan2(axis[1], axis[0])
    previous = _local_proposals(center, angle, scorer.thresholds, {"initialization": "previous_accepted_corners"})
    nearby = scorer.score((center, angle, {}), "local")
    count, top = 0, []
    used_previous = (nearby is not None and nearby["mask_coverage"] >= config.min_mask_coverage
                     and nearby["edge_support"] >= config.min_corner_edge_support)
    if used_previous:
        count, top = _rank(previous, "local", scorer, config)
        if _accepted_candidate(top, config.min_mask_coverage, config.min_corner_edge_support):
            return count, top

    pose = beam_pose(scorer.chamfer, center, angle)
    if pose is not None:
        coarse_center, coarse_angle = pose
        refined = _local_proposals(coarse_center, coarse_angle, scorer.thresholds,
                                   {"initialization": "directional_chamfer_beam"})
        evaluated, candidates = _rank(refined, "local", scorer, config)
        count += evaluated
        if _accepted_candidate(candidates, config.min_mask_coverage, config.min_corner_edge_support):
            return count, candidates

    if used_previous:
        return count, top
    evaluated, top = _rank(previous, "local", scorer, config)
    return count + evaluated, top


def _rank_complete(method, scorer, config, lines, corners):
    def polish(seeds):
        candidates = (proposal for center, angle, provenance in seeds
                      for proposal in _local_proposals(center, angle, scorer.thresholds, provenance))
        return _rank(candidates, method, scorer, config)

    if method == "corner":
        seeds = _corner_proposals(corners, scorer.view["size"])
        coarse_count, top = _rank(seeds, method, scorer, config)
        selected = [(np.asarray(item["center_work"]), np.radians(item["angle_deg"]), item["provenance"])
                    for item in top[:3]]
        count, refined = polish(selected)
        return coarse_count + count, refined

    rank_seeds = polish if config.refine_rounds else lambda proposals: _rank(proposals, method, scorer, config)
    if method == "edge":
        seeds, coarse_count = _edge_beam(scorer, lines, int(config.refine_rounds))
        count, top = rank_seeds(seeds)
        return coarse_count + count, top

    seeds, coarse_count = _mask_beam(scorer, [scorer.center], config)
    count, top = rank_seeds(seeds)
    if _accepted_candidate(top, config.min_mask_coverage, 0):
        return coarse_count + count, top

    bbox_center = (scorer.all_points.min(axis=0) + scorer.all_points.max(axis=0)) / 2
    offsets = np.array([[0, 0], [-1, 0], [1, 0], [0, -1], [0, 1]], dtype=float)
    offsets *= [scorer.thresholds["search_width"], scorer.thresholds["search_depth"]]
    seeds, retry_coarse = _mask_beam(scorer, bbox_center + offsets, config)
    retry_count, retry_top = rank_seeds(seeds)
    return coarse_count + count + retry_coarse + retry_count, retry_top or top


def fit_tray(image, mask, size, *, image_to_plane=None, config=None, initial_corners=None):
    """Fit one rectangular tray; size is in pixels or calibrated plane units.

    Results are geometry proposals requiring visual validation, not measured
    accuracy guarantees. All image corners refer to the original input image.
    """
    config = config or TrayConfig()
    config.validate()
    image = np.asarray(image)
    mask = np.asarray(mask)
    size = np.asarray(size, dtype=float)
    if image.dtype != np.uint8 or image.ndim != 3 or image.shape[2] != 3:
        raise ValueError("image must be a uint8 BGR image")
    if mask.ndim != 2 or mask.shape != image.shape[:2] or not np.isfinite(mask).all():
        raise ValueError("mask must be finite and match the original image dimensions")
    mask = mask != 0
    if not mask.any():
        raise ValueError("Cannot fit a tray to an empty mask")
    if size.shape != (2,) or not np.isfinite(size).all() or (size <= 0).any():
        raise ValueError("size must be a positive finite width/depth pair")
    if initial_corners is not None:
        initial_corners = np.asarray(initial_corners, dtype=float)
        if initial_corners.shape != (4, 2) or not np.isfinite(initial_corners).all():
            raise ValueError("initial_corners must be four finite cyclic image points")
    margin = percent_to_length(config.roi_margin_pct, 1, name="roi_margin_pct")
    view = make_work_view(image, mask, size, image_to_plane, config.max_work_size, margin)
    lengths = _work_lengths(view["size"], config)
    local = initial_corners is not None and config.mode == "auto"
    raw, lines = _line_pool(view, config, lengths, merge=not local)
    corners = [] if local else _corners(lines, config, view["mask"].shape, lengths)
    scorer = _Scorer(view, raw, image.shape, config, lengths)
    stages, chosen = [], None
    for method in (("local", "corner", "edge", "mask") if local else ("corner", "edge", "mask")):
        if config.mode != "auto" and config.mode != method:
            continue
        if method == "corner" and local:
            lines = _merged_pool(raw, config, lengths)
            corners = _corners(lines, config, view["mask"].shape, lengths)
        if method == "local":
            count, top = _rank_local(initial_corners, scorer, config)
        else:
            count, top = _rank_complete(method, scorer, config, lines, corners)
        threshold = (config.min_corner_edge_support if method in ("corner", "local") else
                     config.min_single_edge_support if method == "edge" else 0)
        accepted_item = _accepted_candidate(top, config.min_mask_coverage, threshold)
        accepted = accepted_item is not None
        stages.append({"method": method, "candidate_count": count, "accepted": accepted, "top": top,
                       "accepted_index": top.index(accepted_item) if accepted else None})
        if accepted:
            chosen = accepted_item
            break
    success = chosen is not None
    if chosen is None:
        available = [stage["top"][0] for stage in stages if stage["top"]]
        chosen = max(available, key=lambda item: item["mask_coverage"]) if available else None
    return {"success": success, "needs_review": True, "best": chosen,
            "coordinate_space": "image_pixels" if image_to_plane is None else "calibrated_plane",
            "requested_size": size.tolist(), "corner_order": "cyclic; width follows reported angle",
            "config": asdict(config), "stages": stages,
            "percentage_basis": {"local_lengths": "tray_short_side_work_px",
                                 "tray_short_side_work_px": float(min(view["size"])),
                                 "search": "tray_width_and_depth_work_px", "tray_size_work_px": view["size"].tolist(),
                                 "roi_margin": "bbox_max_span_padding_and_tray_diagonal_radius_multiplier"},
            "resolved_lengths_work_px": lengths,
            "image_to_work": view["image_to_work"].tolist(), "work_size": list(view["mask"].shape[::-1]),
            "raw_lines_work": raw.tolist(), "candidate_lines_work": lines.tolist(),
            "corner_candidates_work": [{"point": c["point"].tolist(), "line_indices": c["line_indices"],
                                         "strength": c["strength"]} for c in corners]}
