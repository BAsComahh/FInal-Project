from pathlib import Path
from time import perf_counter
import json
import sys

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

WORKSPACE = Path(__file__).resolve().parent.parent
PROJECT = Path("C:/Users/vasco/Desktop/FInal Project")
sys.path.insert(0, str(PROJECT))
from components.boundary_detection.tray import detector

ARCHIVE = PROJECT / "outputs/sam3_registration/frame_5b58dfca4481"
FONT_FILE = Path("C:/Windows/Fonts/segoeui.ttf")
CHINESE_FONT = Path("C:/Windows/Fonts/msyh.ttc")
# These segments were marked from the original crops before running either ranking.
VISIBLE_EDGES = {
    "test5": [((41, 60), (167, 49)), ((39, 119), (174, 110)), ((25, 70), (28, 111)),
              ((181, 59), (184, 102))],
    "A4.4": [((25, 21), (97, 19)), ((28, 88), (98, 86)), ((20, 28), (21, 81)),
              ((105, 26), (106, 81))],
    "A9.1": [((25, 20), (113, 20))],
    "B5.1": [((42, 99), (195, 102)), ((201, 48), (201, 97))],
    "A4.2": [((32, 20), (104, 20)), ((109, 25), (109, 83)), ((80, 89), (104, 89))],
    "A7.1": [((35, 29), (194, 29)), ((199, 34), (199, 94)), ((30, 34), (30, 94)),
              ((34, 98), (64, 99)), ((147, 99), (194, 99))],
}


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_image(path, mode=cv2.IMREAD_COLOR):
    image = cv2.imdecode(np.fromfile(path, dtype=np.uint8), mode)
    if image is None:
        raise ValueError(f"Unreadable image: {path}")
    return image


def samples():
    yield ("test5", read_image(PROJECT / "inputs/test5.png"),
           read_image(PROJECT / "outputs/tray_detection/test5_long_unit/test5_input_mask.png",
                      cv2.IMREAD_GRAYSCALE), (160, 60), None)
    image = read_image(ARCHIVE / "frame.png")
    homography = read_json(ARCHIVE / "prompts.json")["homography"]
    mapping = np.asarray(homography["image_to_board"]) @ np.asarray(homography["inverse_matrix"])
    units = read_json(ARCHIVE / "units.json")["roster"]["unit_types"]
    dimensions = {unit["type_id"]: unit["dimension"] for unit in units}
    for instance in read_json(ARCHIVE / "instances.json")["instances"]:
        selection_dir = (ARCHIVE / instance["selection"]).parent
        selection = read_json(selection_dir / "selection.json")
        mask = read_image(selection_dir / selection["mask"], cv2.IMREAD_GRAYSCALE)
        assert mask.shape == image.shape[:2] and mask.any(), instance["unit_id"]
        dimension = dimensions[instance["type_id"]]
        yield instance["unit_id"], image, mask, (dimension["width_mm"], dimension["depth_mm"]), mapping


def crop_box(sample):
    _, image, mask, size, _ = sample
    x, y, width, height = cv2.boundingRect(mask)
    padding = max(19, round(max(size) / 7))
    return (max(0, x - padding), max(0, y - padding),
            min(image.shape[1], x + width + padding), min(image.shape[0], y + height + padding))


def rgb(image):
    return Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))


def inspect(sample_list):
    cell = (280, 204)
    sheet = Image.new("RGB", (cell[0] * 5, cell[1] * 5), "#f5f5f3")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.truetype(FONT_FILE, 18)
    for index, sample in enumerate(sample_list):
        name, image, *_ = sample
        x1, y1, x2, y2 = crop_box(sample)
        tile = rgb(image[y1:y2, x1:x2])
        tile.thumbnail((cell[0] - 20, cell[1] - 40), Image.Resampling.LANCZOS)
        x = cell[0] * (index % 5)
        y = cell[1] * (index // 5)
        sheet.paste(tile, (x + 10, y + 32))
        draw.text((x + 10, y + 6), name, fill="#18201e", font=font)
    sheet.save(WORKSPACE / "work/chamfer-originals.png")

    sheet = Image.new("RGB", (1240, 840), "#f5f5f3")
    draw = ImageDraw.Draw(sheet)
    axis_font = ImageFont.truetype(FONT_FILE, 14)
    by_name = {sample[0]: sample for sample in sample_list}
    names = ("A4.2", "A7.1") if "--extra" in sys.argv else VISIBLE_EDGES
    for index, name in enumerate(names):
        sample = by_name[name]
        x1, y1, x2, y2 = crop_box(sample)
        left, top = (index % 2) * 620 + 42, (index // 2) * 420 + 55
        width, height = x2 - x1, y2 - y1
        scale = min(560 / width, 345 / height, 4)
        tile = rgb(sample[1][y1:y2, x1:x2]).resize(
            (round(width * scale), round(height * scale)), Image.Resampling.LANCZOS)
        sheet.paste(tile, (left, top))
        draw.text((left, top - 51), name, fill="#18201e", font=font)
        layer = Image.new("RGBA", sheet.size)
        grid = ImageDraw.Draw(layer)
        for x in range(0, width, 20):
            px = left + round(x * scale)
            grid.line((px, top, px, top + tile.height), fill=(255, 255, 255, 65))
            draw.text((px, top - 22), str(x), font=axis_font, fill="#18201e", anchor="ma")
        for y in range(0, height, 20):
            py = top + round(y * scale)
            grid.line((left, py, left + tile.width, py), fill=(255, 255, 255, 65))
            draw.text((left - 7, py), str(y), font=axis_font, fill="#18201e", anchor="rm")
        sheet.paste(layer, (0, 0), layer)
        print(name, (x1, y1, x2, y2), scale)
    sheet.save(WORKSPACE / "work/chamfer-review-inputs.png")


def segment_distances(points, starts, ends):
    delta = ends - starts
    offset = points[..., None, :] - starts
    fraction = np.clip(np.sum(offset * delta, axis=-1) / np.sum(delta ** 2, axis=-1), 0, 1)
    return np.linalg.norm(offset - fraction[..., None] * delta, axis=-1)


def directional_support(polygon, scorer):
    edges = np.roll(polygon, -1, axis=0) - polygon
    directions = edges / np.linalg.norm(edges, axis=1, keepdims=True)
    angle = np.arccos(np.clip(np.abs(directions @ scorer.directions.T), 0, 1))
    angle_scale = scorer.tolerance / np.radians(scorer.config.angle_tolerance_deg)
    samples = polygon[:, None, :] + np.linspace(0.03, 0.97, 24)[None, :, None] * edges[:, None, :]
    distance = segment_distances(samples, scorer.raw[:, :2], scorer.raw[:, 2:])
    cost = np.min(distance + angle_scale * angle[:, None, :], axis=-1)
    return float(np.exp(-0.5 * (cost / scorer.tolerance) ** 2).mean())


def compare(sample):
    name, image, mask, size, mapping = sample
    proposals = {"corner": {}, "edge": {}}
    original = detector._Scorer.score
    scorer_used = None

    def capture(scorer, proposal, method, *, exact=False):
        nonlocal scorer_used
        result = original(scorer, proposal, method, exact=exact)
        if result is not None and not exact and method in proposals:
            scorer_used = scorer
            center, angle, _ = proposal
            angle = float(angle % np.pi)
            key = tuple(np.round([*center, angle], 8))
            proposals[method].setdefault(key, (center, angle, proposal[2]))
        return result

    detector._Scorer.score = capture
    try:
        baseline_report = detector.fit_tray(image, mask, size, image_to_plane=mapping)
    finally:
        detector._Scorer.score = original

    stage = next((s["method"] for s in baseline_report["stages"] if s["accepted"]), None)
    method = stage if stage in proposals else next((m for m in ("edge", "corner") if proposals[m]), None)
    stats = dict(unit=name, production_stage=stage, compared_stage=method)
    if method is None:
        return stats
    old_best = new_best = None
    old_score = soft_score = -np.inf
    valid_count = 0
    for proposal in proposals[method].values():
        old = original(scorer_used, proposal, method, exact=True)
        if old is None:
            continue
        valid_count += 1
        # Only the edge term changes. Both candidates use the same exact mask terms.
        support = directional_support(np.asarray(old["corners_work"]), scorer_used)
        score = 0.55 * support + 0.35 * old["mask_coverage"] + 0.10 * old["mask_iou"]
        if old["score"] > old_score:
            old_best, old_score = old, old["score"]
        if score > soft_score:
            new_best, soft_score = {**old, "score": float(score), "edge_support": support}, score
    assert valid_count and old_best is not None and new_best is not None
    old_polygon = np.asarray(old_best["corners_image"])
    new_polygon = np.asarray(new_best["corners_image"])
    period = 90 if size[0] == size[1] else 180
    angle_delta = abs((old_best["angle_deg"] - new_best["angle_deg"] + period / 2) % period - period / 2)
    center_delta = np.linalg.norm(old_polygon.mean(axis=0) - new_polygon.mean(axis=0))
    stats.update(candidates=valid_count, center_delta_px=float(center_delta), angle_delta_deg=float(angle_delta),
                 old_corners=old_polygon.tolist(), new_corners=new_polygon.tolist())
    if name in VISIBLE_EDGES:
        origin = np.asarray(crop_box(sample)[:2])
        marked = np.asarray(VISIBLE_EDGES[name]) + origin
        starts, ends = marked[:, 0], marked[:, 1]
        fractions = np.linspace(0, 1, 32)[None, :, None]
        points = starts[:, None] + fractions * (ends - starts)[:, None]
        stats["reference_edges"] = marked.tolist()
        stats["edge_errors_px"] = [
            float(segment_distances(points, polygon, np.roll(polygon, -1, axis=0)).min(axis=-1).mean())
            for polygon in (old_polygon, new_polygon)
        ]
    return stats


def render(results, sample_list):
    canvas = Image.new("RGB", (1392, 150 + 248 * len(VISIBLE_EDGES)), "#f6f6f2")
    draw = ImageDraw.Draw(canvas)
    title = ImageFont.truetype(CHINESE_FONT, 30)
    text = ImageFont.truetype(CHINESE_FONT, 19)
    small = ImageFont.truetype(CHINESE_FONT, 16)
    ink, muted = "#19221e", "#4c5853"
    draw.text((24, 17), "托盘矩形拟合对照", font=title, fill=ink)
    draw.text((24, 58), "同一张图、同一批矩形候选。距离为人工标出的可见边到拟合框的平均距离。",
              font=small, fill=muted)
    columns = (24, 480, 936)
    for x, label in zip(columns, ("人工标出的可见边", "现有评分", "方向 Chamfer 评分")):
        draw.text((x, 94), label, font=text, fill=ink)

    by_name = {sample[0]: sample for sample in sample_list}
    by_result = {result["unit"]: result for result in results}
    examples = (("A4.2", "中心位移最大"), ("A7.1", "第二大中心位移"), ("A4.4", "四边较清楚"),
                ("A9.1", "手和模型遮挡"), ("B5.1", "相邻托盘紧贴"), ("test5", "近似尺寸样例"))
    for index, (name, note) in enumerate(examples):
        result = by_result[name]
        sample = by_name[name]
        left, top, right, bottom = crop_box(sample)
        crop = rgb(sample[1][top:bottom, left:right])
        scale = min(432 / crop.width, 202 / crop.height)
        panel = crop.resize((round(crop.width * scale), round(crop.height * scale)), Image.Resampling.LANCZOS)
        y = 131 + index * 248
        errors = result["edge_errors_px"]
        edits = (result["reference_edges"], [result["old_corners"]], [result["new_corners"]])
        descriptions = (f"{name}  ·  {note}", f"{errors[0]:.1f} px", f"{errors[1]:.1f} px")
        for column, (x, lines, description) in enumerate(zip(columns, edits, descriptions)):
            tile = panel.copy()
            marks = ImageDraw.Draw(tile)
            for line in lines:
                points = (np.asarray(line) - [left, top]) * scale
                if column:
                    points = np.vstack((points, points[0]))
                pixels = [tuple(point) for point in points]
                marks.line(pixels, fill="#152220", width=6)
                marks.line(pixels, fill=("#a7ecab", "#ffd16b", "#6aebfb")[column], width=3)
            canvas.paste(tile, (x, y + 28))
            draw.text((x, y), description, font=small, fill=ink)
        draw.line((24, y + 237, 1368, y + 237), fill="#d4d9d3")
    canvas.save(WORKSPACE / "outputs/chamfer-comparison.png")


if __name__ == "__main__":
    sample_list = list(samples())
    if "--inspect" in sys.argv:
        inspect(sample_list)
    else:
        # A point 1 px from a vertical segment and 3 px from a horizontal segment.
        distances = segment_distances(np.array([[0, 0]]), np.array([[1, -1], [-1, 3]]),
                                      np.array([[1, 1], [1, 3]]))
        assert np.array_equal(distances, [[1, 3]])
        results = []
        for sample in sample_list:
            start = perf_counter()
            result = compare(sample)
            results.append(result)
            print(result["unit"], result["production_stage"], result.get("candidates"),
                  round(result.get("center_delta_px", 0), 2), round(result.get("angle_delta_deg", 0), 2),
                  result.get("edge_errors_px"), round(perf_counter() - start, 2), flush=True)
        (WORKSPACE / "work/chamfer-comparison.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
        render(results, sample_list)
