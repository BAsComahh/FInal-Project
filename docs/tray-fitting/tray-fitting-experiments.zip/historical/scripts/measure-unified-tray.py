import importlib.util
import json
from pathlib import Path
import runpy
import sys
from time import perf_counter
from types import ModuleType

import cv2
import numpy as np


work = Path(__file__).resolve().parent
fixture = runpy.run_path(str(work / 'chamfer-a-b.py'))
detector = fixture['detector']
package = ModuleType('components.boundary_detection.tray_before_unified')
package.__path__ = [str(Path(detector.__file__).parent)]
sys.modules[package.__name__] = package


def archived_module(name):
    fullname = f'{package.__name__}.{name}'
    spec = importlib.util.spec_from_file_location(fullname, work / 'tray-before-unified' / f'{name}.py')
    module = importlib.util.module_from_spec(spec)
    sys.modules[fullname] = module
    spec.loader.exec_module(module)
    return module


archived_module('directional_chamfer')
before = archived_module('detector')
cv2.setNumThreads(1)


def geometry_delta(previous, current):
    if previous is None or current is None:
        return None
    a, b = np.asarray(previous), np.asarray(current)
    return min(float(np.sqrt(np.mean(np.sum((a - np.roll(b, shift, axis=0)) ** 2, axis=1))))
               for shift in range(4))


def evaluate(sample, module, seed, coverage):
    _, image, mask, size, mapping = sample
    start = perf_counter()
    result = module.fit_tray(image, mask, size, image_to_plane=mapping, initial_corners=seed,
                             config=module.TrayConfig(min_mask_coverage=coverage))
    elapsed = (perf_counter() - start) * 1000
    best = result['best']
    return {
        'ms': elapsed,
        'success': result['success'],
        'method': best['method'] if best else None,
        'coverage': best['mask_coverage'] if best else None,
        'max_coverage': max((x['mask_coverage'] for stage in result['stages'] for x in stage['top']), default=0),
        'stages': [[stage['method'], stage['candidate_count'], stage.get('beam_rounds')]
                   for stage in result['stages']],
        'corners': best['corners_image'] if best else None,
    }


def seed_for(corners, mapping, size, shift, rotation, direction):
    transform = detector.transform_points
    plane = transform(corners, mapping)
    center = plane.mean(axis=0)
    theta = np.radians(rotation)
    matrix = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
    plane = (plane - center) @ matrix.T + center + min(size) * shift * direction
    return transform(plane, np.linalg.inv(mapping))


def main():
    samples = [s for s in fixture['samples']() if s[0] not in ('test5', 'B2.1')]
    directions = [(x, y) for x in (-1, 0, 1) for y in (-1, 0, 1) if x or y]
    conditions = [('near', .06, 0, .06), ('turn', .18, 8, .18),
                  ('shift', .32, 0, .32), ('shift', .46, 0, .46), ('shift', .57, 0, .57),
                  ('shift_turn', .68, 8, .68), ('shift', .82, 0, .82), ('shift_turn', 1.1, 12, 1.1),
                  ('centroid_noise', .04, 5, .55), ('rotation_only', 0, 18, 0)]
    output = []
    for i, sample in enumerate(samples):
        unit, _, _, size, mapping = sample
        old_cold = evaluate(sample, before, None, .55)
        old_80_cold = evaluate(sample, before, None, .80)
        new_cold = evaluate(sample, detector, None, .80)
        reference = old_cold['corners']
        assert reference is not None
        direction = np.asarray(directions[i % len(directions)], dtype=float)
        direction /= np.linalg.norm(direction)
        cold_runs = [new_cold]
        row = dict(unit=unit, source_group='validation' if i % 3 == 1 else 'calibration',
                   cold=[old_cold, old_80_cold, new_cold], cases=[])
        for j, (kind, shift, rotation, distance) in enumerate(conditions):
            seed = seed_for(reference, mapping, size, shift, rotation * (-1 if i % 2 else 1), direction)
            cold = evaluate(sample, detector, None, .80) if j in (4, 8) else new_cold
            if cold is not new_cold:
                cold_runs.append(cold)
            new = evaluate(sample, detector, seed, .80)
            case = dict(kind=kind, distance=distance, shift=shift, rotation=rotation, new=new,
                        error=geometry_delta(reference, new['corners']))
            if j < 2:
                case['old'] = evaluate(sample, before, seed, .55)
                case['old80'] = evaluate(sample, before, seed, .80)
            row['cases'].append(case)
        row['cold'][2]['ms'] = float(np.median([run['ms'] for run in cold_runs]))
        row['cold_error'] = geometry_delta(reference, new_cold['corners'])
        output.append(row)
        print(unit, [fit['success'] for fit in row['cold']], round(new_cold['ms'], 1),
              ''.join(case['new']['method'][0] if case['new']['method'] else '-' for case in row['cases']), flush=True)
    (work / 'unified-tray-results.json').write_text(json.dumps(output, indent=2), encoding='utf-8')
    summarize(output)


def summarize(output):
    for subset in ('all', 'calibration', 'validation'):
        rows = [r for r in output if subset == 'all' or r['source_group'] == subset]
        for radius in (.25, .4, .5, .6, .75, 1., 1.25, 1.5, np.inf):
            chosen = [(r['cold'][2] if case['distance'] > radius else case['new'],
                       r['cold_error'] if case['distance'] > radius else case['error'],
                       case['distance'] > radius)
                      for r in rows for case in r['cases']]
            times = np.asarray([v['ms'] for v, _, _ in chosen])
            errors = [e for v, e, _ in chosen if e is not None and v['success']]
            success = sum(v['success'] for v, _, _ in chosen)
            print(subset, radius, 'total', round(times.sum(), 1), 'median/P90',
                  np.percentile(times, [50, 90]).round(1).tolist(), 'accepted', success,
                  'local', sum(v['success'] and v['method'] == 'local' for v, _, _ in chosen),
                  'direct', sum(bypass for _, _, bypass in chosen),
                  'P90 error', round(np.percentile(errors, 90), 2), flush=True)
    for name, engine in (('cold55', 0), ('cold80', 1), ('cold_shared80', 2)):
        chosen = [r['cold'][engine] for r in output]
        print(name, sum(r['success'] for r in chosen), np.percentile([r['ms'] for r in chosen], [50, 90]), flush=True)
    for scenario in ('near', 'turn'):
        for engine in ('old', 'old80', 'new'):
            chosen = [case[engine] for r in output for case in r['cases'] if case['kind'] == scenario]
            print(scenario, engine, sum(r['success'] for r in chosen),
                  sum(r['success'] and r['method'] == 'local' for r in chosen),
                  np.percentile([r['ms'] for r in chosen], [50, 90]), flush=True)


if __name__ == '__main__':
    main()
