import importlib.util
import json
from pathlib import Path
import runpy
import sys
from time import perf_counter

import numpy as np


work = Path(__file__).resolve().parent
previous_experiment = runpy.run_path(str(work / "tray-beam-comparison.py"))
fixture = previous_experiment["experiment"]
detector = fixture["detector"]
baseline_name = f"{detector.__package__}.detector_before_beam"
spec = importlib.util.spec_from_file_location(baseline_name, work / "tray-before/detector.py")
baseline = importlib.util.module_from_spec(spec)
sys.modules[baseline_name] = baseline
spec.loader.exec_module(baseline)
fit = previous_experiment["fit"]
distance = previous_experiment["corner_difference"]
perturb = previous_experiment["perturb"]
directions = previous_experiment["DIRECTIONS"]
samples = list(fixture["samples"]())[1:]
cases = (("near", 0.015, 0), ("translation", 0.28, 0), ("shift_turn", 0.18, 8), ("turn_only", 0, 11))
rows = []
for index, sample in enumerate(samples):
    ref = fit(baseline.fit_tray, sample)
    assert ref["success"] and ref == fit(detector.fit_tray, sample), sample[0]
    target = np.asarray(ref["best"]["corners_image"])
    direction = directions[index % len(directions)].astype(float)
    direction /= np.linalg.norm(direction)
    for group, shift, degrees in cases:
        if group == "turn_only" and index % 3:
            continue
        seed = perturb(target, shift, degrees if index % 2 else -degrees, direction)
        times, reports = [[], []], [None, None]
        for repeat in range(4):
            order = (0, 1) if (repeat + index) % 2 == 0 else (1, 0)
            for impl in order:
                start = perf_counter()
                result = fit((baseline.fit_tray, detector.fit_tray)[impl], sample, seed)
                elapsed = (perf_counter() - start) * 1000
                if repeat:
                    times[impl].append(elapsed)
                    assert result == reports[impl], (sample[0], group, impl)
                reports[impl] = result
        assert all(r["success"] for r in reports), (sample[0], group)
        old_corners, new_corners = (np.asarray(report["best"]["corners_image"]) for report in reports)
        best = reports[1]["best"]
        out = dict(unit=sample[0], group=group, times=times,
                   fallback=[r["best"]["method"] != "local" for r in reports],
                   width_depth=sample[3], changed_px=distance(new_corners, old_corners),
                   delta_vs_fresh_px=[distance(poly, target) for poly in (old_corners, new_corners)],
                   initialization=best["provenance"].get("initialization"),
                   old_corners=old_corners.tolist(), new_corners=new_corners.tolist())
        rows.append(out)
    if index % 6 == 5:
        print(f"Checked {index + 1}/{len(samples)} archive masks", flush=True)

for group, _, _ in cases:
    selection = [row for row in rows if row["group"] == group]
    elapsed = np.asarray([row["times"] for row in selection])
    print(group, "n=", len(selection), "batch ms", np.median(elapsed.sum(axis=0), axis=1).round(1).tolist(),
          "full", np.asarray([row["fallback"] for row in selection]).sum(axis=0).tolist(),
          "beam accept", sum(row["initialization"] == "directional_chamfer_beam" for row in selection),
          "changed >3px", [(row["unit"], round(row["changed_px"], 1), *np.round(row["delta_vs_fresh_px"], 1))
                           for row in selection if row["changed_px"] > 3], flush=True)
(work / "production-directional-beam.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")

# Exercise the real adaptive entry after the detector checks.
from application.tray_worker import update_trays
from components.boundary_detection.tray.temporal import TrayStability

ids = [row["object_id"] for row in fixture["read_json"](fixture["ARCHIVE"] / "instances.json")["instances"]]
sizes = {unit: sample[3] for unit, sample in zip(ids, samples)}
context = {"image_to_plane": samples[0][4], "sizes": sizes}
prediction = {"object_ids": ids, "masks": np.stack([sample[2] != 0 for sample in samples])}
request = {"frame": samples[0][1], "kind": "propagate", "tray_context": context,
           "metadata": {"frame_index": 0}}
before = update_trays(request, prediction, search="adaptive", stability=TrayStability())
assert before["tray_fit_stats"]["refitted"] == 24 and len(before["trays"]) == 24
request["metadata"] = {"frame_index": 1}
after = update_trays(request, prediction, search="adaptive", stability=TrayStability(),
                     previous=before["trays"])
assert after["tray_fit_stats"]["reused"] == 24 and after["tray_fit_stats"]["refitted"] == 0
assert all(before["trays"][unit]["corners_image"] == after["trays"][unit]["corners_image"] for unit in ids)
print("Actual update_trays adaptive entry reused all 24 accepted rectangles.")
