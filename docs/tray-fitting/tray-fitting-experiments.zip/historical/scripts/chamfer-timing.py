import inspect
import json
from pathlib import Path
import runpy
from statistics import median
import textwrap
from time import perf_counter

import numpy as np

WORK = Path(__file__).resolve().parent
experiment = runpy.run_path(str(WORK / "chamfer-a-b.py"))
detector = experiment["detector"]
original_score = detector._Scorer.score
score_source = textwrap.dedent(inspect.getsource(original_score))
edge_start = score_source.index("    support = []")
edge_end = score_source.index("    edge_support =", edge_start)


def support_by_side(polygon, scorer):
    edges = np.roll(polygon, -1, axis=0) - polygon
    directions = edges / np.linalg.norm(edges, axis=1, keepdims=True)
    angles = np.arccos(np.clip(abs(directions @ scorer.directions.T), 0, 1))
    scale = scorer.tolerance / np.radians(scorer.config.angle_tolerance_deg)
    samples = polygon[:, None, :] + np.linspace(0.03, 0.97, 24)[None, :, None] * edges[:, None, :]
    distance = experiment["segment_distances"](samples, scorer.raw[:, :2], scorer.raw[:, 2:])
    cost = np.min(distance + scale * angles[:, None, :], axis=-1)
    return np.exp(-0.5 * (cost / scorer.tolerance) ** 2).mean(axis=1).tolist()


def scorer_with_edge_calculation(calculation):
    source = score_source[:edge_start] + calculation + score_source[edge_end:]
    namespace = dict(vars(detector), support_by_side=support_by_side)
    exec(compile(source, "<temporary-timing-scorer>", "exec"), namespace)
    return namespace["score"]


direct_score = scorer_with_edge_calculation("    support = support_by_side(polygon, self)\n")
deferred_score = scorer_with_edge_calculation(
    '    if method == "mask" and not exact:\n        support = [0.0] * 4\n    else:\n'
    + textwrap.indent(score_source[edge_start:edge_end], "    "))


def fit(sample, score=original_score):
    _, image, mask, size, mapping = sample
    detector._Scorer.score = score
    try:
        return detector.fit_tray(image, mask, size, image_to_plane=mapping)
    finally:
        detector._Scorer.score = original_score


def prepare_pool(sample, expected):
    proposals = {}
    method = expected["compared_stage"]
    scorer_used = None

    def capture(scorer, proposal, stage, *, exact=False):
        nonlocal scorer_used
        item = original_score(scorer, proposal, stage, exact=exact)
        if item is not None and not exact and stage == method:
            scorer_used = scorer
            center, angle, provenance = proposal
            angle = float(angle % np.pi)
            key = tuple(np.round([*center, angle], 8))
            proposals.setdefault(key, (center, angle, provenance))
        return item

    baseline = fit(sample, capture)
    assert len(proposals) == expected["candidates"], sample[0]
    return scorer_used, method, tuple(proposals.values()), baseline


def rank(score, scorer, method, candidates):
    best = None
    for candidate in candidates:
        item = score(scorer, candidate, method, exact=True)
        if item is not None and (best is None or item["score"] > best["score"]):
            best = item
    return best


def timed(call):
    start = perf_counter()
    result = call()
    return (perf_counter() - start) * 1000, result


samples = list(experiment["samples"]())
recorded = json.loads((WORK / "chamfer-comparison.json").read_text(encoding="utf-8"))
assert [sample[0] for sample in samples] == [record["unit"] for record in recorded]
ranking_times = {}
fit_times = {}
for sample, expected in zip(samples, recorded):
    scorer, method, candidates, report = prepare_pool(sample, expected)
    local_rank_times = [[], []]
    local_fit_times = [[], []]
    for repeat in range(6):
        order = (0, 1) if repeat % 2 == 0 else (1, 0)
        for index in order:
            score = (original_score, direct_score)[index]
            elapsed, selected = timed(lambda: rank(score, scorer, method, candidates))
            np.testing.assert_allclose(selected["corners_image"],
                                       expected[("old_corners", "new_corners")[index]], atol=1e-6)
            if repeat:
                local_rank_times[index].append(elapsed)
        for index in order:
            score = (original_score, deferred_score)[index]
            elapsed, candidate_report = timed(lambda: fit(sample, score))
            assert report == candidate_report, sample[0]
            if repeat:
                local_fit_times[index].append(elapsed)
    ranking_times[sample[0]] = local_rank_times
    fit_times[sample[0]] = local_fit_times
    if sample[0] in ("test5", "B2.1", "A9.1") or len(ranking_times) in (10, 20, 25):
        print(sample[0], "ranking ms", [round(median(x), 1) for x in local_rank_times],
              "full fitting ms", [round(median(x), 1) for x in local_fit_times], flush=True)


def batch_totals(records, names):
    return np.asarray([records[name] for name in names]).sum(axis=0)


archive_names = [sample[0] for sample in samples if sample[0] != "test5"]
ranking_batch = batch_totals(ranking_times, archive_names)
fit_batch = batch_totals(fit_times, archive_names)
print("Archive ranking total paired medians (ms):", np.median(ranking_batch, axis=1).round(1).tolist())
print("Archive full fitting total paired medians (ms):", np.median(fit_batch, axis=1).round(1).tolist())
(WORK / "chamfer-timing.json").write_text(json.dumps({
    "compared": len(samples), "paired_runs": 5, "ranking_ms": ranking_times, "full_fit_ms": fit_times,
    "archive_ranking_total_ms": ranking_batch.tolist(), "archive_full_fit_total_ms": fit_batch.tolist(),
}, indent=2), encoding="utf-8")
