import inspect
import json
from pathlib import Path
import runpy
import textwrap
from time import perf_counter

import cv2
import numpy as np


WORK = Path(__file__).resolve().parent
experiment = runpy.run_path(str(WORK / "chamfer-a-b.py"))
detector = experiment["detector"]
DIRECTIONS = np.array([(x, y) for x in (-1, 0, 1) for y in (-1, 0, 1) if x or y])
FRACTIONS = np.linspace(0.03, 0.97, 24)[None, :, None]
MODES = ("current", "translation_beam", "angle_greedy", "angle_beam")


def beam_seed(corners, scorer, view, *, beam_width=3, search_angles=False):
    """Search translations and optional angle offsets on cached distance fields."""
    points = detector.transform_points(corners, view["image_to_work"])
    center = points.mean(axis=0)
    axis = points[1] - points[0]
    angle = np.arctan2(axis[1], axis[0])
    if not len(scorer.raw):
        return None

    height, width = view["mask"].shape
    cap = 3 * scorer.tolerance
    cache_fields = {}
    cache_angles = {}

    def distance_field(matches):
        key = matches.tobytes()
        if key in cache_fields:
            return cache_fields[key]
        if not matches.any():
            field = np.full((height, width), cap, dtype=np.float32)
        else:
            pixels = np.ones((height, width), dtype=np.uint8)
            for ax, ay, bx, by in np.rint(scorer.raw[matches] * 16).astype(int):
                cv2.line(pixels, (ax, ay), (bx, by), 0, 1, shift=4)
            field = np.minimum(cv2.distanceTransform(pixels, cv2.DIST_L2, cv2.DIST_MASK_5), cap)
        cache_fields[key] = field
        return field

    def angle_data(slot):
        if slot not in cache_angles:
            theta = angle + np.radians(4 * slot)
            u = np.array([np.cos(theta), np.sin(theta)])
            directions = np.array([u, [-u[1], u[0]]])
            aligned = np.abs(directions @ scorer.directions.T) >= np.cos(
                np.radians(scorer.config.angle_tolerance_deg))
            fields = np.stack([distance_field(matches) for matches in aligned])
            polygon = detector.rectangle(np.zeros(2), theta, view["size"])
            offsets = polygon[:, None, :] + FRACTIONS * (np.roll(polygon, -1, axis=0) - polygon)[:, None]
            cache_angles[slot] = (fields, polygon, offsets)
        return cache_angles[slot]

    # A coarse move is one tenth of the short side. Precision comes from the legacy search.
    step = max(1.0, float(min(view["size"])) * 0.10)
    costs = {}

    def score(states):
        grid = np.asarray(states)
        for slot in np.unique(grid[:, 2]):
            indices = grid[:, 2] == slot
            positions = center + grid[indices, :2] * step
            fields, polygon, samples = angle_data(slot)
            lower = -polygon.min(axis=0)
            upper = np.array([width - 1, height - 1]) - polygon.max(axis=0)
            valid = ((positions >= lower) & (positions <= upper)).all(axis=1)
            coordinates = np.rint(positions[:, None, None, :] + samples).astype(int)
            x = np.clip(coordinates[..., 0], 0, width - 1)
            y = np.clip(coordinates[..., 1], 0, height - 1)
            distances = fields[np.array([0, 1, 0, 1])[None, :, None], y, x]
            for state, cost in zip(grid[indices], np.where(valid, distances.mean(axis=(1, 2)), np.inf)):
                costs[tuple(state)] = float(cost)

    origin = (0, 0, 0)
    beam = [origin]
    score(beam)
    best_cost = costs[origin]
    # The first round checks the angle range; follow-up rounds only check local neighbors.
    for round_number in range(4):
        frontier = set(beam)
        for x, y, slot in beam:
            if not search_angles:
                slots = (slot,)
            elif round_number == 0:
                slots = range(-3, 4)
            else:
                slots = range(max(-3, slot - 1), min(3, slot + 1) + 1)
            for neighbor in slots:
                frontier.add((x, y, neighbor))
                frontier.update((x + dx, y + dy, neighbor) for dx, dy in DIRECTIONS)
        fresh = sorted(frontier.difference(costs))
        if not fresh:
            break
        score(fresh)
        beam = sorted(frontier, key=lambda node: (
            costs[node], node[0] ** 2 + node[1] ** 2, abs(node[2]), node))[:beam_width]
        current_cost = costs[beam[0]]
        if current_cost >= best_cost - 0.02 * scorer.tolerance:
            break
        best_cost = current_cost
    if beam[0] == origin or not np.isfinite(costs[beam[0]]):
        return None
    x, y, slot = beam[0]
    _, polygon, _ = angle_data(slot)
    shifted = polygon + center + np.asarray([x, y]) * step
    return detector.transform_points(shifted, view["work_to_image"])


def rank_local(proposals, method, scorer, config, view, corners, lengths, *,
               beam_first, search_angles, beam_width):
    if method != "local":
        return detector._rank(proposals, method, scorer, config)

    def accepted(result):
        return any(item["mask_coverage"] >= config.min_mask_coverage
                   and item["edge_support"] >= config.min_corner_edge_support for item in result[1])

    if beam_first:
        seed = beam_seed(corners, scorer, view, beam_width=beam_width, search_angles=search_angles)
        if seed is not None:
            shifted = detector._rank(detector._local_proposals(seed, view, lengths), method, scorer, config)
            if accepted(shifted):
                shifted[1][0]["beam_used"] = True
                return shifted
        return detector._rank(proposals, method, scorer, config)

    original = detector._rank(proposals, method, scorer, config)
    if accepted(original):
        return original
    seed = beam_seed(corners, scorer, view, beam_width=beam_width, search_angles=search_angles)
    if seed is None:
        return original
    shifted = detector._rank(detector._local_proposals(seed, view, lengths), method, scorer, config)
    if accepted(shifted):
        shifted[1][0]["beam_used"] = True
        return shifted
    return original


def make_prototype(beam_first, *, search_angles=False, beam_width=3):
    source = textwrap.dedent(inspect.getsource(detector.fit_tray))
    original = "        count, top = _rank(proposals, method, scorer, config)\n"
    assert source.count(original) == 1
    replacement = ("        count, top = rank_local(proposals, method, scorer, config, view, "
                   f"initial_corners, lengths, beam_first={beam_first}, "
                   f"search_angles={search_angles}, beam_width={beam_width})\n")
    namespace = dict(vars(detector), rank_local=rank_local)
    exec(compile(source.replace(original, replacement), "<temporary-beam-fit>", "exec"), namespace)
    return namespace["fit_tray"]


def fit(fitter, sample, seed=None):
    _, image, mask, size, mapping = sample
    return fitter(image, mask, size, image_to_plane=mapping, initial_corners=seed)


def perturb(corners, shift, degrees, direction):
    center = corners.mean(axis=0)
    side = np.linalg.norm(corners - np.roll(corners, -1, axis=0), axis=1).min()
    angle = np.radians(degrees)
    rotation = np.array([[np.cos(angle), np.sin(angle)], [-np.sin(angle), np.cos(angle)]])
    return (corners - center) @ rotation + center + direction * (shift * side)


def corner_difference(actual, reference):
    return min(float(np.sqrt(np.sum((np.roll(actual, n, axis=0) - reference) ** 2, axis=1).mean()))
               for n in range(4))


def run():
    samples = list(experiment["samples"]())[1:]
    fitters = (detector.fit_tray, make_prototype(True),
               make_prototype(True, search_angles=True, beam_width=1),
               make_prototype(True, search_angles=True, beam_width=3))
    groups = (("near", 0.015, 0.0), ("translation", 0.28, 0.0),
              ("shift_turn", 0.18, 8.0), ("turn_only", 0.0, 11.0))
    rows = []
    for index, sample in enumerate(samples):
        reference = fit(detector.fit_tray, sample)
        assert reference["success"], sample[0]
        target = np.asarray(reference["best"]["corners_image"])
        direction = DIRECTIONS[index % len(DIRECTIONS)].astype(float)
        direction /= np.linalg.norm(direction)
        for name, shift, degrees in groups:
            if name == "turn_only" and index % 3 != 0:
                continue
            seed = perturb(target, shift, degrees if index % 2 else -degrees, direction)
            times = [[] for _ in fitters]
            reports = [None for _ in fitters]
            for repeat in range(4):
                order = np.roll(np.arange(len(fitters)), (index + repeat) % len(fitters))
                for variant in order:
                    start = perf_counter()
                    result = fit(fitters[variant], sample, seed)
                    elapsed = (perf_counter() - start) * 1000
                    if repeat:
                        times[variant].append(elapsed)
                        assert result == reports[variant], (sample[0], name, MODES[variant])
                    reports[variant] = result

            assert reports[0]["success"]
            baseline = np.asarray(reports[0]["best"]["corners_image"])
            for mode, report, measurements in zip(MODES, reports, times):
                result = np.asarray(report["best"]["corners_image"]) if report["success"] else None
                rows.append(dict(unit=sample[0], group=name, mode=mode, ms=measurements,
                                 local=report["stages"][0]["accepted"], success=report["success"],
                                 shift_vs_current=None if result is None else corner_difference(result, baseline),
                                 error_vs_full=None if result is None else corner_difference(result, target)))
        if index % 6 == 5 or index == len(samples) - 1:
            print(f"Completed {index + 1}/{len(samples)} units", flush=True)
    (WORK / "tray-angle-comparison.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    for group, *_ in groups:
        for mode in MODES:
            cases = [row for row in rows if row["group"] == group and row["mode"] == mode]
            time = np.array([row["ms"] for row in cases])
            reference_difference = [row["error_vs_full"] for row in cases if row["success"]]
            changed = sorted(((row["unit"], round(row["shift_vs_current"], 1), round(row["error_vs_full"], 1))
                              for row in cases if row["success"] and row["shift_vs_current"] > 3),
                             key=lambda item: -item[1])
            print(group, mode, "batch ms", round(np.median(time.sum(axis=0)), 1),
                  "object p50 ms", round(np.median(np.median(time, axis=1)), 1),
                  "full fallbacks", sum(not row["local"] for row in cases), "success",
                  sum(row["success"] for row in cases), "median vs full px",
                  round(np.median(reference_difference), 1), "changed by >3 px", changed, flush=True)


if __name__ == "__main__":
    run()
