import json
from pathlib import Path
import runpy

import cv2
import numpy as np

work = Path(__file__).resolve().parent
benchmark = runpy.run_path(str(work / 'measure-unified-tray.py'))
detector, fixture, geometry_delta = (benchmark[key] for key in ('detector', 'fixture', 'geometry_delta'))
from components.boundary_detection.tray.batch import fit_registered_trays


def self_check():
    size = (116, 60)
    center = np.array([136., 96.])
    angle = np.radians(22)
    polygon = detector.rectangle(center, angle, size)
    corners = np.rint(polygon).astype(np.int32)
    mask = np.zeros((214, 268), dtype=np.uint8)
    cv2.fillConvexPoly(mask, corners, 1)
    flat = np.full((*mask.shape, 3), 220, dtype=np.uint8)
    image = flat.copy()
    edge = flat.copy()
    cv2.polylines(image, [corners], True, (33, 40, 50), 2)
    a, z = corners[0], corners[1]
    cv2.line(edge, tuple(a + (z - a) // 15), tuple(z - (z - a) // 15), (33, 40, 50), 1)
    for mode, frame in (('corner', image), ('edge', edge), ('mask', flat)):
        result = detector.fit_tray(frame, mask, size, config=detector.TrayConfig(mode=mode))
        assert result['success'] and result['best']['method'] == mode, mode
        assert geometry_delta(polygon, result['best']['corners_image']) < 5, mode
        print(mode, result['stages'][0]['beam_rounds'], round(result['best']['mask_coverage'], 3), flush=True)
    zero = detector.fit_tray(flat, mask, size, config=detector.TrayConfig(mode='mask', refine_rounds=0))
    assert zero['success'] and zero['stages'][0]['beam_rounds'] == 0
    pose = detector.rectangle(center + [16, -8], angle + np.radians(8), size)
    result = detector.fit_tray(image, mask, size, initial_corners=pose)
    assert result['success'] and result['best']['method'] == 'local'
    assert result['best']['provenance'] == {'initialization': 'previous_accepted_corners'}
    for proposal, rotation in detector._beam_neighbors(center, angle, 6):
        if rotation != angle:
            np.testing.assert_array_equal(center, proposal)
            np.testing.assert_allclose(abs(rotation - angle), np.radians(5))
        else:
            np.testing.assert_allclose(np.linalg.norm(proposal - center), 6)
    assert len(list(detector._beam_neighbors(center, angle, 6))) == 10
    for method in ('local', 'corner', 'edge', 'mask'):
        gate = detector._min_edge_support(method, detector.TrayConfig())
        assert detector._accepted_candidate([dict(mask_coverage=.8, edge_support=gate)], .8, gate)
        assert not detector._accepted_candidate([dict(mask_coverage=.7999, edge_support=gate)], .8, gate)
    auto = detector.fit_tray(flat, mask, size, initial_corners=pose)
    assert [stage['method'] for stage in auto['stages']] == ['local', 'corner', 'edge', 'mask']
    assert auto['success'] and auto['best']['method'] == 'mask'
    print('Shared neighborhood, 80% threshold boundaries, local provenance and fallback order passed.', flush=True)


def track(sample, anchor):
    _, image, mask, size, mapping = sample
    h, w = mask.shape
    transform = detector.transform_points
    center = transform(anchor, mapping).mean(axis=0)
    inv = np.linalg.inv(mapping)
    side = min(size)
    for offset, deg in ((0, 0), (.006, 0), (.09, 5), (.645, 5), (.72, 10), (.12, -10), (.51, 0), (.51, 0)):
        theta = np.radians(deg)
        turn = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
        motion = np.eye(3)
        motion[:2, :2] = turn
        motion[:2, 2] = center - turn @ center + np.array([offset * side, 0])
        move = inv @ motion @ mapping
        moved = cv2.warpPerspective(image, move, (w, h))
        moved_mask = cv2.warpPerspective(mask, move, (w, h), flags=cv2.INTER_NEAREST)
        yield moved, moved_mask, transform(anchor, move)


def replay(samples, baseline):
    rows = []
    for index, sample in enumerate(samples):
        name, _, _, size, mapping = sample
        anchor = baseline[name]['cold'][0]['corners']
        observations = list(track(sample, anchor))
        for threshold in ((.50, .60, None) if index % 2 else (None, .60, .50)):
            previous = {}
            for frame_index, (image, mask, expected) in enumerate(observations):
                attempts = {}
                trays, errors = fit_registered_trays(image, dict(object_ids=[1], masks=[mask]),
                                                     dict(sizes={1: size}, image_to_plane=mapping),
                                                     previous=previous, reuse_stable=True,
                                                     source_frame=frame_index, attempts=attempts,
                                                     full_search_distance=threshold)
                outcome = attempts[1]
                check = outcome.get('reuse_check') or {}
                if threshold is not None and 'direct_full' in check:
                    assert check['direct_full'] == (check['refit_displacement_short_sides'] > threshold)
                    if check['direct_full'] and trays:
                        assert trays[1]['method'] not in ('local', 'stable_reuse')
                rows.append(dict(unit=name, threshold=threshold, frame=frame_index, success=bool(trays),
                                 ms=outcome['seconds'] * 1000, direct=check.get('direct_full', False),
                                 reuse=not outcome['attempted'], method=outcome.get('method'),
                                 error=geometry_delta(outcome.get('corners_image'), expected)))
                previous = attempts

    for threshold in (None, .50, .60):
        selected = [r for r in rows if r['threshold'] == threshold]
        times = [r['ms'] for r in selected if r['frame'] and not r['reuse']]
        errors = [r['error'] for r in selected if r['success']]
        print('Replay', threshold, 'counts', len(selected), sum(r['success'] for r in selected),
              'reuse', sum(r['reuse'] for r in selected), 'direct', sum(r['direct'] for r in selected),
              'local', sum(r['method'] == 'local' for r in selected),
              'refits med/P90', np.percentile(times, [50, 90]).round(1).tolist(), 'refits total', round(sum(times), 1),
              'error P90', round(np.percentile(errors, 90), 2), flush=True)
    return rows


def main():
    self_check()
    baseline = {row['unit']: row for row in json.loads((work / 'unified-tray-results.json').read_text())}
    selection = [s for s in fixture['samples']() if s[0] in baseline
                 and baseline[s[0]]['source_group'] == 'validation']
    rows = replay(selection, baseline)
    (work / 'unified-tray-replay.json').write_text(json.dumps(rows, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
