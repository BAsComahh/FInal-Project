import importlib.util
import json
from pathlib import Path
import runpy
import sys
from time import perf_counter
from types import ModuleType

import cv2
import numpy as np


work = Path(__file__).resolve().parent
fixture = runpy.run_path(str(work / "tray-beam-comparison.py"))
detector = fixture["detector"]
snapshot = work / "tray-before-full-beam/components/boundary_detection/tray"
baseline_package = "components.boundary_detection.tray_before_full_beam"
package = ModuleType(baseline_package)
package.__path__ = [str(Path(detector.__file__).resolve().parent)]
sys.modules[baseline_package] = package


def load_before(module):
    name = f"{baseline_package}.{module}"
    spec = importlib.util.spec_from_file_location(name, snapshot / f"{module}.py")
    loaded = importlib.util.module_from_spec(spec)
    sys.modules[name] = loaded
    spec.loader.exec_module(loaded)
    return loaded


load_before("directional_chamfer")
before = load_before("detector")


def synthetic():
    from components.boundary_detection.tray.visualization import diagnostic_images

    size = (116, 60)
    center = np.array([136., 96.])
    angle = np.radians(22)
    polygon = detector.rectangle(center, angle, size)
    corners = np.rint(polygon).astype(np.int32)
    mask = np.zeros((214, 268), dtype=np.uint8)
    cv2.fillConvexPoly(mask, corners, 1)
    flat = np.full((*mask.shape, 3), 220, dtype=np.uint8)
    image = flat.copy()
    edge = flat.copy()
    cv2.polylines(image, [corners], True, (33, 40, 50), 2)
    a, z = corners[0], corners[1]
    cv2.line(edge, tuple(a + (z - a) // 15), tuple(z - (z - a) // 15), (33, 40, 50), 1)
    for mode, frame, limit in (("corner", image, 130), ("edge", edge, 135), ("mask", flat, 350)):
        old = before.fit_tray(frame, mask, size, config=before.TrayConfig(mode=mode))
        result = detector.fit_tray(frame, mask, size, config=detector.TrayConfig(mode=mode))
        stage = result["stages"][0]
        print(mode, "before", old["success"], old["stages"][0]["candidate_count"],
              "after", result["success"], stage["candidate_count"], result["best"]["provenance"], flush=True)
        assert result["success"] and stage["method"] == mode and stage["candidate_count"] < limit
        assert np.linalg.norm(np.asarray(result["best"]["corners_image"]).mean(axis=0) - center) < 4.5
        dims = np.linalg.norm(np.roll(result["best"]["corners_plane"], -1, axis=0)
                              - np.asarray(result["best"]["corners_plane"]), axis=1)
        np.testing.assert_allclose(dims, [116, 60, 116, 60])
        assert "stages" in diagnostic_images(frame, mask, result)
    zero = detector.fit_tray(flat, mask, size, config=detector.TrayConfig(mode="mask", refine_rounds=0))
    assert zero["success"] and zero["stages"][0]["candidate_count"] <= 39
    seed = detector.rectangle(center + [17, -10], angle + np.radians(8), size)
    local = detector.fit_tray(image, mask, size, initial_corners=seed)
    assert local == before.fit_tray(image, mask, size, initial_corners=seed)
    assert local["success"] and local["best"]["method"] == "local"
    assert local["best"]["provenance"]["initialization"] == "directional_chamfer_beam"
    print("Synthetic corner, partial single edge, mask, zero rounds, and local Beam passed.", flush=True)


def benchmark():
    samples = list(fixture["experiment"]["samples"]())[1:]
    fit = fixture["fit"]
    directions = fixture["DIRECTIONS"]
    perturb = fixture["perturb"]
    distance = fixture["corner_difference"]
    scenarios = ("cold", "near", "shift_turn")
    rows = []
    for index, sample in enumerate(samples):
        reference = fit(before.fit_tray, sample)
        assert reference["success"]
        target = np.asarray(reference["best"]["corners_image"])
        direction = directions[index % len(directions)].astype(float)
        direction /= np.linalg.norm(direction)
        for scenario in scenarios:
            if scenario == "cold":
                seed = None
            elif scenario == "near":
                seed = perturb(target, 0.015, 0, direction)
            else:
                seed = perturb(target, 0.18, 8 if index % 2 else -8, direction)
            times, reports = [[], []], [None, None]
            for repeat in range(4):
                order = (0, 1) if (repeat + index) % 2 == 0 else (1, 0)
                for implementation in order:
                    start = perf_counter()
                    result = fit((before.fit_tray, detector.fit_tray)[implementation], sample, seed)
                    elapsed = (perf_counter() - start) * 1000
                    if repeat:
                        times[implementation].append(elapsed)
                        assert result == reports[implementation], (sample[0], scenario, implementation)
                    reports[implementation] = result
            best = [report["best"] for report in reports]
            delta = distance(*(np.asarray(item["corners_image"]) for item in best)) if all(best) else None
            change = dict(unit=sample[0], scenario=scenario, times=times,
                          success=[r["success"] for r in reports], stages=[item["method"] if item else None for item in best],
                          counts=[sum(s["candidate_count"] for s in r["stages"]) for r in reports],
                          exact_match=best[0] == best[1], corner_difference_px=delta,
                          corners=[item["corners_image"] if item else None for item in best])
            rows.append(change)
        if index % 6 == 5:
            print(f"Checked {index + 1}/{len(samples)} units", flush=True)
    for scenario in scenarios:
        selection = [row for row in rows if row["scenario"] == scenario]
        elapsed = np.asarray([row["times"] for row in selection])
        print(scenario, "batch ms", np.median(elapsed.sum(axis=0), axis=1).round(1).tolist(),
              "success", np.asarray([row["success"] for row in selection]).sum(axis=0).tolist(),
              "counts", np.asarray([row["counts"] for row in selection]).sum(axis=0).tolist(),
              "stages", [row["stages"] for row in selection if row["stages"][0] != row["stages"][1]],
              "corner delta over 3px", [(r["unit"], round(r["corner_difference_px"], 1))
                                        for r in selection if (r["corner_difference_px"] or 0) > 3], flush=True)
    (work / "full-directional-beam.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")


if __name__ == "__main__":
    synthetic()
    if "--synthetic" not in sys.argv:
        benchmark()
