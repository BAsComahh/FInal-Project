"""Paired CPU fitting benchmark. Run against the project and saved registration frame."""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import random
import sys
from time import perf_counter_ns

os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['OMP_NUM_THREADS'] = '1'
import cv2
import numpy as np


SCENARIOS = {
    'full': (None, 0),
    'near': (.06, 0),
    'shift_turn': (.18, 8),
    'far': (.65, 0),
}
DIRECTIONS = [(x, y) for x in (-1, 0, 1) for y in (-1, 0, 1) if x or y]


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def read_image(path, mode):
    frame = cv2.imdecode(np.fromfile(path, dtype=np.uint8), mode)
    if frame is None:
        raise ValueError(f'Cannot read {path}')
    return frame


def archived_units(archive):
    frame = read_image(archive / 'frame.png', cv2.IMREAD_COLOR)
    prompts = read_json(archive / 'prompts.json')
    homography = prompts['homography']
    mapping = np.asarray(homography['image_to_board']) @ np.asarray(homography['inverse_matrix'])
    types = read_json(archive / 'units.json')['roster']['unit_types']
    dimensions = {unit['type_id']: unit['dimension'] for unit in types}
    units = []
    for instance in read_json(archive / 'instances.json')['instances']:
        name = instance['unit_id']
        if name == 'B2.1':
            continue
        selection_path = archive / instance['selection']
        mask_path = selection_path.parent / read_json(selection_path)['mask']
        mask = read_image(mask_path, cv2.IMREAD_GRAYSCALE) != 0
        dimension = dimensions[instance['type_id']]
        size = (dimension['width_mm'], dimension['depth_mm'])
        units.append((name, mask, size, mask_path.relative_to(archive).as_posix()))
    return frame, prompts.get('frame_index'), mapping, units


def load_baseline(current, baseline):
    module_name = f'{current.__package__}.detector_before_beam'
    spec = importlib.util.spec_from_file_location(module_name, baseline)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def displaced(transform, corners, mapping, inverse, size, direction, shift, angle):
    table = transform(corners, mapping)
    center = table.mean(axis=0)
    theta = np.radians(angle)
    turn = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
    changed = (table - center) @ turn.T + center + np.asarray(direction) * (min(size) * shift)
    return transform(changed, inverse)


def result_metrics(result, reference):
    best = result.get('best')
    delta = None
    if best:
        corners = np.asarray(best['corners_image'])
        delta = min(float(np.sqrt(np.mean(np.sum((reference - np.roll(corners, j, axis=0)) ** 2, axis=1))))
                    for j in range(4))
    return {
        'success': bool(result['success']), 'method': best['method'] if best else None,
        'coverage': best['mask_coverage'] if best else None,
        'edge_support': best['edge_support'] if best else None,
        'corner_rms_vs_old55_cold_px': delta,
        'stages': [{k: stage.get(k) for k in ('method', 'candidate_count', 'accepted', 'beam_rounds')}
                   for stage in result['stages']],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--repeats', type=int, default=5)
    args = parser.parse_args()
    sys.path.insert(0, str(args.project.resolve()))
    from components.boundary_detection.tray import batch
    from components.boundary_detection.tray import detector as current

    cv2.setNumThreads(1)
    archive = args.project / 'outputs/sam3_registration/frame_5b58dfca4481'
    frame, frame_index, mapping, units = archived_units(archive)
    inverse = np.linalg.inv(mapping)
    old = load_baseline(current, args.baseline)
    old_default = old.TrayConfig()
    old_matched = old.TrayConfig(min_mask_coverage=.70)
    current_default = current.TrayConfig()
    cutoff = batch.fit_registered_trays.__kwdefaults__['full_search_distance']
    assert old_default.min_mask_coverage == .55 and current_default.min_mask_coverage == .70 and cutoff == .50
    versions = {'old55': (old.fit_tray, old_default), 'old70': (old.fit_tray, old_matched),
                'new70': (current.fit_tray, current_default),
                'new70_local_first': (current.fit_tray, current_default)}
    rng = random.Random(20261118)
    rows = []
    input_rows = []
    for index, (unit, mask, size, mask_path) in enumerate(units):
        baseline = old.fit_tray(frame, mask, size, image_to_plane=mapping, config=old_default)
        assert baseline['success'], unit
        reference = np.asarray(baseline['best']['corners_image'])
        direction = np.asarray(DIRECTIONS[index % len(DIRECTIONS)], dtype=float)
        direction /= np.linalg.norm(direction)
        input_rows.append({'unit': unit, 'size_mm': size, 'mask': mask_path, 'direction': direction.tolist(),
                           'reference_corners_image': reference.tolist()})
        scenarios = list(SCENARIOS.items())
        rng.shuffle(scenarios)
        for scenario, (shift, angle) in scenarios:
            rotation = angle * (-1 if index % 2 else 1)
            prior = None if shift is None else displaced(current.transform_points, reference, mapping, inverse,
                                                         size, direction, shift, rotation)
            names = ['old55', 'old70', 'new70']
            if shift is not None and shift > cutoff:
                names.append('new70_local_first')
            metrics = {}
            for repeat in range(-1, args.repeats):
                rng.shuffle(names)
                for order, name in enumerate(names):
                    fit, config = versions[name]
                    seed = None if name == 'new70' and shift is not None and shift > cutoff else prior
                    start = perf_counter_ns()
                    report = fit(frame, mask, size, image_to_plane=mapping, config=config, initial_corners=seed)
                    elapsed_ms = (perf_counter_ns() - start) / 1e6
                    if repeat < 0:
                        metrics[name] = result_metrics(report, reference)
                        continue
                    observed = result_metrics(report, reference)
                    assert observed == metrics[name], (unit, scenario, name)
                    rows.append(dict(unit=unit, scenario=scenario, variant=name, repeat=repeat + 1,
                                     execution_order=order + 1, elapsed_ms=elapsed_ms, shift_short_sides=shift,
                                     rotation_deg=rotation, sent_previous_pose=seed is not None,
                                     coverage_gate=config.min_mask_coverage, **observed))
        print(f'{index + 1}/{len(units)} {unit}', flush=True)

    paths = [args.baseline, Path(current.__file__), Path(batch.__file__),
             Path(current.__file__).with_name('directional_chamfer.py')]
    data = {
        'archive': archive.name, 'source_frame_index': frame_index, 'repeats': args.repeats,
        'cpu': os.environ.get('PROCESSOR_NAME') or os.environ.get('PROCESSOR_IDENTIFIER') or platform.processor(),
        'os': platform.platform(), 'python': platform.python_version(), 'numpy': np.__version__,
        'opencv': cv2.__version__, 'time_scope': 'fit_tray only, includes any attempted fallback',
        'source_hashes_sha256': {f'{p.parent.name}/{p.name}': hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        'excluded_units': {'B2.1': 'Archived size mismatch, excluded before timing'},
        'image_to_board': mapping.tolist(), 'source_cases': input_rows, 'trials': rows,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(data, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
