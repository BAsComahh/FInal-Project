import csv
import json
from collections import defaultdict
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, ScalarFormatter
import numpy as np


work = Path(__file__).resolve().parent
staging = work / 'tray-thesis'
outputs = work.parent / 'outputs'
project = Path('C:/Users/vasco/Desktop/FInal Project')
archive_json = staging / 'paired-timing.json'
scenario_labels = {
    'full': 'Full search from scratch',
    'near': 'Small translation',
    'shift_turn': 'Translation and rotation',
    'far': 'Large translation',
}
scenario_zh = dict(full='直接完整搜索', near='旧框平移短边 6%', shift_turn='旧框平移短边 18% 并旋转 8°',
                   far='旧框平移短边 65%')
variant_labels = dict(old55='Original, 55%', old70='Original', new70='Shared Beam',
                      new70_local_first='Beam, local first')
colors = dict(old70='#657182', new70='#096e6d', new70_local_first='#ad6927')


def write_csv(path, rows):
    keys = list(rows[0])
    with path.open('w', encoding='utf-8-sig', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def per_unit_trials(trials):
    groups = defaultdict(list)
    for row in trials:
        groups[row['scenario'], row['variant'], row['unit']].append(row)
    units = []
    for (scenario, variant, unit), records in groups.items():
        first = records[0]
        times = [r['elapsed_ms'] for r in records]
        accepted_method = first['method'] if first['success'] else None
        stages = first['stages']
        units.append(dict(scenario=scenario, variant=variant, unit=unit, median_ms=float(np.median(times)),
                          trials=len(times), accepted=first['success'], accepted_method=accepted_method,
                          had_local=first['sent_previous_pose'], fell_back=stages[0]['method'] == 'local' and len(stages) > 1,
                          final_stage=stages[-1]['method'], mask_coverage=first['coverage'],
                          edge_support=first['edge_support'], candidate_count=sum(s['candidate_count'] for s in stages),
                          corner_rms_vs_old55_cold_px=first['corner_rms_vs_old55_cold_px']))
    return units


def summaries(units):
    report = []
    for scenario in scenario_labels:
        for variant in variant_labels:
            matches = [r for r in units if r['scenario'] == scenario and r['variant'] == variant]
            if not matches:
                continue
            times = np.asarray([r['median_ms'] for r in matches])
            errors = [r['corner_rms_vs_old55_cold_px'] for r in matches if r['accepted']]
            report.append(dict(scenario=scenario, variant=variant, units=len(matches),
                               median_ms=float(np.median(times)), p90_ms=float(np.percentile(times, 90)),
                               sum_of_unit_medians_ms=float(np.sum(times)), accepted=sum(r['accepted'] for r in matches),
                               accepted_local=sum(r['accepted_method'] == 'local' for r in matches),
                               fell_back=sum(r['fell_back'] for r in matches),
                               corner_rms_p90_vs_old55_cold_px=float(np.percentile(errors, 90)) if errors else None))
    return report


def local_pairs(units):
    result = []
    for scenario in ('near', 'shift_turn', 'far'):
        old = {r['unit']: r for r in units if r['scenario'] == scenario and r['variant'] == 'old70'
               and r['accepted_method'] == 'local'}
        new = {r['unit']: r for r in units if r['scenario'] == scenario and r['variant'] == 'new70'
               and r['accepted_method'] == 'local'}
        names = sorted(old.keys() & new.keys())
        if not names:
            continue
        elapsed_old, elapsed_new = ([source[name]['median_ms'] for name in names] for source in (old, new))
        result.append(dict(scenario=scenario, paired_local=len(names), original_median_ms=float(np.median(elapsed_old)),
                           beam_median_ms=float(np.median(elapsed_new)),
                           original_p90_ms=float(np.percentile(elapsed_old, 90)),
                           beam_p90_ms=float(np.percentile(elapsed_new, 90))))
    return result


def plot(units, stats, repeats):
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'pdf.fonttype': 42, 'font.size': 10, 'text.color': '#182537'})
    fig, axes = plt.subplots(2, 2, figsize=(10.5, 6.4), gridspec_kw={'wspace': .38, 'hspace': .60})
    fig.subplots_adjust(left=.15, right=.975, top=.807, bottom=.18)
    fig.text(.035, .951, 'Tray fitting time on a saved video frame', fontsize=19, weight='bold')
    fig.text(.035, .903, f'23 trays  ·  Common 70% mask coverage gate  ·  {repeats} timed runs per tray and condition',
             fontsize=10.5, color='#4a586b')
    measured = [r['median_ms'] for r in units if r['variant'] != 'old55']
    upper = 2 ** np.ceil(np.log2(max(measured) * 1.06))
    lower = 2 ** np.floor(np.log2(min(measured) * .92))
    ticks = np.array([4, 8, 16, 32, 64, 128, 256, 512, 1024])
    titles = dict(full='A   Full search from scratch', near='B   Small translation (6%)',
                  shift_turn='C   Translation (18%) and rotation (8°)', far='D   Large translation (65%)')
    for ax, scenario in zip(axes.ravel(), scenario_labels):
        variants = ['old70', 'new70']
        if scenario == 'far':
            variants.append('new70_local_first')
        values = {v: {r['unit']: r['median_ms'] for r in units if r['scenario'] == scenario and r['variant'] == v}
                  for v in variants}
        names = sorted(values['old70'])
        jitter = np.random.default_rng(711).uniform(-.21, .21, len(names))
        for i, unit in enumerate(names):
            for y in range(len(variants) - 1):
                ax.plot([values[variants[y]][unit], values[variants[y+1]][unit]],
                        [y+jitter[i], y+1+jitter[i]], color='#cad1d9', linewidth=.55, alpha=.53, zorder=1)
        labels = []
        for y, variant in enumerate(variants):
            s = stats[scenario, variant]
            elapsed = [values[variant][unit] for unit in names]
            ax.scatter(elapsed, y+jitter, s=17, color=colors[variant], alpha=.69, linewidth=0, zorder=2)
            ax.scatter([s['median_ms']], [y], s=61, marker='D', color=colors[variant],
                       edgecolors='white', linewidths=1.15, zorder=3)
            tag = variant_labels[variant]
            labels.append(f"{tag}\n{s['median_ms']:.1f} ms")
        ax.set_title(titles[scenario], loc='left', pad=9, fontsize=11.1, weight='bold')
        ax.set_xscale('log', base=2)
        ax.set_xlim(lower, upper)
        ax.xaxis.set_major_locator(FixedLocator(ticks[(ticks >= lower) & (ticks <= upper)]))
        ax.xaxis.set_major_formatter(ScalarFormatter())
        ax.set_yticks(range(len(variants)), labels=labels, fontsize=9)
        ax.set_ylim(len(variants)-.58, -.49)
        ax.tick_params(axis='both', length=0, labelcolor='#4a586b', pad=6)
        ax.grid(axis='x', color='#e3e9ef', linewidth=.8)
        ax.spines[['left', 'right', 'top', 'bottom']].set_visible(False)
    fig.text(.56, .113, 'CPU time per tray (ms, log scale)', ha='center', fontsize=10.5)
    fig.text(.035, .054, 'Dots show per-tray medians. Lines pair the same tray. Diamonds show the median across trays.',
             fontsize=9, color='#4a586b')
    fig.savefig(outputs / 'tray-fitting-speed.pdf', facecolor='white', metadata={'Title': 'Tray fitting time on a saved video frame'})
    fig.savefig(outputs / 'tray-fitting-speed.png', facecolor='white', dpi=300)
    plt.close(fig)


def plot_paths(stats, pairs):
    local = next(r for r in pairs if r['scenario'] == 'near')
    full = [stats['full', variant] for variant in ('old70', 'new70')]
    panels = [
        (f"A   Full search from scratch  (n = {full[0]['units']})",
         [(run['median_ms'], run['p90_ms']) for run in full]),
        (f"B   Both fitters accepted a local result  (n = {local['paired_local']})",
         [(local['original_median_ms'], local['original_p90_ms']),
          (local['beam_median_ms'], local['beam_p90_ms'])]),
    ]
    fig, axes = plt.subplots(2, 1, figsize=(8.6, 4.8), sharex=True)
    fig.subplots_adjust(left=.19, right=.89, top=.765, bottom=.20, hspace=.66)
    fig.text(.032, .944, 'Local and full tray fitting time', fontsize=19, weight='bold')
    fig.text(.032, .891, 'Original fitter and shared Beam at the same 70% coverage gate', fontsize=10.5, color='#4a586b')
    for ax, (title, points) in zip(axes, panels):
        for y, (median, p90) in enumerate(points):
            color = colors['old70' if y == 0 else 'new70']
            ax.barh(y, median, color=color, height=.40, zorder=2)
            ax.hlines(y, median, p90, color=color, linewidth=1.35, zorder=3)
            ax.vlines(p90, y-.10, y+.10, color=color, linewidth=1.35, zorder=3)
            ax.text(median - 1.4, y, f'{median:.1f}', ha='right', va='center', fontsize=8.6,
                    color='white', weight='bold', zorder=4)
            ax.text(p90+1.25, y, f'{p90:.1f}', ha='left', va='center', fontsize=8.6, color=color)
        ax.set_title(title, loc='left', pad=10, weight='bold', fontsize=11)
        ax.set_yticks([0, 1], labels=['Original', 'Shared Beam'])
        ax.set_ylim(1.65, -.65)
        ax.set_xlim(0, 128)
        ax.set_xticks([0, 20, 40, 60, 80, 100, 120])
        ax.grid(axis='x', color='#e3e9ef', linewidth=.8)
        ax.tick_params(axis='both', length=0, labelcolor='#4a586b', pad=7)
        ax.spines[['left', 'right', 'top', 'bottom']].set_visible(False)
    fig.text(.55, .105, 'CPU time per tray (ms)', ha='center', fontsize=10.5)
    fig.text(.032, .044, 'Bars show medians. Caps show P90. The local pairs come from the 6% translation condition.',
             fontsize=9, color='#4a586b')
    fig.savefig(outputs / 'tray-local-vs-full.pdf', facecolor='white', metadata={'Title': 'Local and full tray fitting time'})
    fig.savefig(outputs / 'tray-local-vs-full.png', facecolor='white', dpi=300)
    plt.close(fig)


def write_report(stats, pairs, metadata):
    direct_old, direct_new = stats['full', 'old70'], stats['full', 'new70']
    near_old, near_new = stats['near', 'old70'], stats['near', 'new70']
    turn_old, turn_new = stats['shift_turn', 'old70'], stats['shift_turn', 'new70']
    far_old, far_new = stats['far', 'old70'], stats['far', 'new70']
    far_try = stats['far', 'new70_local_first']
    reduction = 100 * (1 - direct_new['median_ms'] / direct_old['median_ms'])
    count = direct_old['units']
    lines = [
        '# 托盘拟合速度对照', '',
        '原流程取自引入 Beam 之前保留的检测器快照。新流程使用共用三路方向 Chamfer Beam、27 点精调和当前 70% 门槛。主对照把原流程也设为 70%。原流程按历史默认 55% 的结果另存于汇总表，用于复核验收门槛的影响。',
        '', '## 同一 70% 验收门槛下的耗时', '',
        '| 输入条件 | 原流程中位／P90（ms） | 新流程中位／P90（ms） | 局部接纳 原 → 新 | 整体通过 原 → 新 |',
        '| --- | ---: | ---: | ---: | ---: |',
    ]
    for scenario in scenario_labels:
        a, b = stats[scenario, 'old70'], stats[scenario, 'new70']
        lines.append(f"| {scenario_zh[scenario]} | {a['median_ms']:.1f}／{a['p90_ms']:.1f} | "
                     f"{b['median_ms']:.1f}／{b['p90_ms']:.1f} | {a['accepted_local']} → {b['accepted_local']} | "
                     f"{a['accepted']}/{count} → {b['accepted']}/{count} |")
    lines += [
        '', f"直接完整搜索的单单位中位耗时下降 **{reduction:.1f}%**。大位移组新流程按当前距离规则直接进入完整搜索。"
        f"若让同一个新检测器先试局部，大位移组中位耗时为 **{far_try['median_ms']:.1f} ms**，P90 为 **{far_try['p90_ms']:.1f} ms**，其中 {far_try['fell_back']}/{count} 个单位进入完整回退。直接完整的中位耗时为 {far_new['median_ms']:.1f} ms，P90 为 {far_new['p90_ms']:.1f} ms。",
        '', '## 两套流程都成功走局部的配对样本', '',
        '| 输入条件 | 配对单位数 | 原流程中位／P90（ms） | 新流程中位／P90（ms） |',
        '| --- | ---: | ---: | ---: |',
    ]
    for entry in pairs:
        lines.append(f"| {scenario_zh[entry['scenario']]} | {entry['paired_local']} | "
                     f"{entry['original_median_ms']:.1f}／{entry['original_p90_ms']:.1f} | "
                     f"{entry['beam_median_ms']:.1f}／{entry['beam_p90_ms']:.1f} |")
    lines += [
        '', '只在两套流程均接纳局部结果的同一单位上计算本表。小位移下，共用 Beam 在这 12 个单位上耗时略高。纳入全组后，原流程 11 个单位发生完整回退，新流程有 3 个，所以全组中位耗时下降。',
        '', '## 实验设置', '',
        f"- 数据取自 `{metadata['archive']}` 视频第 {metadata['source_frame_index']} 帧的 {count} 个有效单位。固定同一原图、mask、标定和已登记托盘尺寸，按此前决定排除 B2.1。",
        '- 直接完整搜索不传旧框。其余三组用原流程完整搜索的接纳框，按短边比例在标定桌面平面偏移，并在指定组绕中心旋转。65% 组模拟超过 50% 质心距离门槛时的路由。',
        f"- AMD Ryzen 7 9850X3D，Python {metadata['python']}，OpenCV {metadata['opencv']}，NumPy {metadata['numpy']}。OpenCV、OpenBLAS 和 OMP 各限制为单线程。每个单位、场景和版本预热一次，计时 {metadata['repeats']} 次，版本执行顺序用固定随机种子打散。",
        '- 计时范围是 `fit_tray`，包含 ROI、LSD、搜索、精调及该调用中的完整回退。模型推理、视频解码、稳定复用和重拟合路由的质心比较耗时在计时之外。',
        '- 先对每单位的重复测量取中位数，再报告跨单位中位数和 P90。统计单位是在同一帧中各托盘的配对结果。四角差异以旧版完整拟合为参照，适用于说明结果变化。结论限于这组受控输入，真实直播速度和实体托盘误差需要单独测量。',
        '', '## English text for the thesis', '',
        f"We compared the original tray fitter with shared directional Chamfer beam search on {count} trays from one archived video frame, "
        f"using a common 70% mask coverage gate and five timed runs per tray and condition. For fitting from scratch, the median CPU time "
        f"per tray fell from {direct_old['median_ms']:.1f} to {direct_new['median_ms']:.1f} ms ({reduction:.1f}% lower). "
        f"For a translation of 6% of the short side, the corresponding times were {near_old['median_ms']:.1f} and {near_new['median_ms']:.1f} ms. "
        f"For an 18% translation combined with an 8° rotation, they were {turn_old['median_ms']:.1f} and {turn_new['median_ms']:.1f} ms. "
        f"For a 65% translation, the deployed route entered full search directly and took {far_new['median_ms']:.1f} ms "
        f"compared with {far_old['median_ms']:.1f} ms for the original fitter. The workload uses fixed segmentation masks and controlled perturbations of the previous tray pose.",
    ]
    (outputs / 'tray-fitting-evaluation.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')


HISTORICAL = {
    'chamfer-comparison.json': '方向 Chamfer 重新排序、候选和人工标注可见边的比较。',
    'chamfer-timing.json': '方向 Chamfer 候选排序与整次拟合的配对预实验。',
    'tray-beam-comparison.json': '平移优先的局部 Beam 探索。',
    'tray-angle-comparison.json': '带旋转的贪心与 Beam 搜索对照。',
    'production-directional-beam.json': '原局部拟合与首版方向 Chamfer Beam 的配对结果。',
    'full-directional-beam.json': '首版局部 Beam 与后来局部和完整搜索修改的对照。',
    'unified-tray-results.json': '80% 门槛下共享 Beam、六轮局部和距离截断的配对试验。每单位十种扰动。',
    'unified-tray-replay.json': '80% 门槛下对 8 个留出单位施加已知变换的顺序回放。',
}


def archive():
    index = ['# 托盘拟合实验数据', '', '本包保存会话中已落盘的原始对照数据及 70% 公用门槛的新配对实验。旧档保留当时的筛选、门槛与方法，部分旧档含 B2.1。',
             '', '## 新配对实验', '',
             '- `current/paired-timing.json` 含 70% 同门槛对照、旧默认 55% 对照、源输入尺寸和 mask 路径、计时顺序与文件散列。',
             '- `current/trials.csv` 含每次实测及回退阶段。`per-unit.csv` 汇总每单位的中位数，`summary.csv` 汇总各场景，`paired-local.csv` 只保留新旧均走局部的配对单位。',
             '- `source/pre-beam/detector.py` 为原流程冻结快照。`source/shared-beam/` 为 70% 实验所用的相关实现。运行 `scripts/tray-thesis-benchmark.py --help` 查看复跑参数。复跑使用项目原有 Python 依赖和 `outputs/sam3_registration/frame_5b58dfca4481` 存档。',
             '- `report/` 包含论文图和结果说明。', '', '## 历史数据', '']
    index.extend(f'- `historical/{name}` {description}' for name, description in HISTORICAL.items())
    with ZipFile(outputs / 'tray-fitting-experiments.zip', 'w', compression=ZIP_DEFLATED) as zipped:
        zipped.writestr('README.md', '\n'.join(index) + '\n')
        zipped.writestr('historical/conversation-notes.md', '''# Earlier CPU timing notes

The raw repeats for these two short checks were reported in the conversation as summaries.

- ROI, raw LSD, collinear merging and right-corner pairing were timed on 23 archived units, excluding B2.1. Medians were 2.62, 1.23, 4.58 and 11.01 ms respectively. Combined preparation with ROI was 3.81 ms for local fitting and 19.29 ms for full fitting, with P90 at 6.11 and 30.02 ms. Search and scoring were outside this timing.
- Earlier four-round versus six-round check, B5.1 at a half-short-side offset. Direct full search took about 72.1 ms, four-round local then full took 114.2 ms, and reaching the solution in up to six local rounds took 35.8 ms. This example was selected because the four-round run failed locally.
''')
        for name in HISTORICAL:
            zipped.write(work / name, arcname=f'historical/{name}')
        for name in ('chamfer-a-b.py', 'chamfer-timing.py', 'tray-beam-comparison.py', 'verify-tray-directional-beam.py',
                     'verify-full-tray-beam.py', 'measure-unified-tray.py', 'replay-unified-tray.py'):
            zipped.write(work / name, arcname=f'historical/scripts/{name}')
        for name in ('tray-before', 'tray-before-full-beam', 'tray-before-unified'):
            for path in (work / name).rglob('*.py'):
                zipped.write(path, arcname=f'historical/snapshots/{path.relative_to(work).as_posix()}')
        for name in ('b2-1-tray-fit-stages.png', 'chamfer-comparison.png', 'tray-a1-1-coverage.png', 'tray-beam-accuracy.png'):
            zipped.write(outputs / name, arcname=f'historical/figures/{name}')
        for name in ('paired-timing.json', 'trials.csv', 'per-unit.csv', 'summary.csv', 'paired-local.csv'):
            zipped.write(staging / name, arcname=f'current/{name}')
        zipped.write(work / 'tray-before/detector.py', arcname='source/pre-beam/detector.py')
        for name in ('detector.py', 'directional_chamfer.py', 'batch.py', 'temporal.py'):
            zipped.write(project / 'components/boundary_detection/tray' / name, arcname=f'source/shared-beam/{name}')
        for name in ('tray-thesis-benchmark.py', 'package-tray-thesis.py'):
            zipped.write(work / name, arcname=f'scripts/{name}')
        for name in ('tray-fitting-evaluation.md', 'tray-fitting-speed.pdf', 'tray-local-vs-full.pdf'):
            zipped.write(outputs / name, arcname=f'report/{name}')


def main():
    data = json.loads(archive_json.read_text(encoding='utf-8'))
    trials = data['trials']
    units = per_unit_trials(trials)
    summary = summaries(units)
    matched = local_pairs(units)
    assert len(units) == 23 * 13 and len(trials) == len(units) * data['repeats']
    stats = {(r['scenario'], r['variant']): r for r in summary}
    flat_trials = [dict(r, stages=json.dumps(r['stages'], separators=(',', ':'))) for r in trials]
    write_csv(staging / 'trials.csv', flat_trials)
    write_csv(staging / 'per-unit.csv', units)
    write_csv(staging / 'summary.csv', summary)
    write_csv(staging / 'paired-local.csv', matched)
    write_report(stats, matched, data)
    plot(units, stats, data['repeats'])
    plot_paths(stats, matched)
    archive()


if __name__ == '__main__':
    main()
