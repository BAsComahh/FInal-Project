# 托盘拟合实验数据

本包保存会话中已落盘的原始对照数据及 70% 公用门槛的新配对实验。旧档保留当时的筛选、门槛与方法，部分旧档含 B2.1。

## 新配对实验

- `current/paired-timing.json` 含 70% 同门槛对照、旧默认 55% 对照、源输入尺寸和 mask 路径、计时顺序与文件散列。
- `current/trials.csv` 含每次实测及回退阶段。`per-unit.csv` 汇总每单位的中位数，`summary.csv` 汇总各场景，`paired-local.csv` 只保留新旧均走局部的配对单位。
- `source/pre-beam/detector.py` 为原流程冻结快照。`source/shared-beam/` 为 70% 实验所用的相关实现。运行 `scripts/tray-thesis-benchmark.py --help` 查看复跑参数。复跑使用项目原有 Python 依赖和 `outputs/sam3_registration/frame_5b58dfca4481` 存档。
- `report/` 包含论文图和结果说明。

## 历史数据

- `historical/chamfer-comparison.json` 方向 Chamfer 重新排序、候选和人工标注可见边的比较。
- `historical/chamfer-timing.json` 方向 Chamfer 候选排序与整次拟合的配对预实验。
- `historical/tray-beam-comparison.json` 平移优先的局部 Beam 探索。
- `historical/tray-angle-comparison.json` 带旋转的贪心与 Beam 搜索对照。
- `historical/production-directional-beam.json` 原局部拟合与首版方向 Chamfer Beam 的配对结果。
- `historical/full-directional-beam.json` 首版局部 Beam 与后来局部和完整搜索修改的对照。
- `historical/unified-tray-results.json` 80% 门槛下共享 Beam、六轮局部和距离截断的配对试验。每单位十种扰动。
- `historical/unified-tray-replay.json` 80% 门槛下对 8 个留出单位施加已知变换的顺序回放。
