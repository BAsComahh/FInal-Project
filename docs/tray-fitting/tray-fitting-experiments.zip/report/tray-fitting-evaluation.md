# 托盘拟合速度对照

原流程取自引入 Beam 之前保留的检测器快照。新流程使用共用三路方向 Chamfer Beam、27 点精调和当前 70% 门槛。主对照把原流程也设为 70%。原流程按历史默认 55% 的结果另存于汇总表，用于复核验收门槛的影响。

## 同一 70% 验收门槛下的耗时

| 输入条件 | 原流程中位／P90（ms） | 新流程中位／P90（ms） | 局部接纳 原 → 新 | 整体通过 原 → 新 |
| --- | ---: | ---: | ---: | ---: |
| 直接完整搜索 | 85.6／113.6 | 38.6／60.1 | 0 → 0 | 23/23 → 23/23 |
| 旧框平移短边 6% | 32.8／117.0 | 25.0／42.1 | 12 → 20 | 23/23 → 23/23 |
| 旧框平移短边 18% 并旋转 8° | 104.1／148.0 | 28.7／41.2 | 0 → 22 | 23/23 → 23/23 |
| 旧框平移短边 65% | 100.8／128.1 | 37.6／60.4 | 0 → 0 | 23/23 → 23/23 |

直接完整搜索的单单位中位耗时下降 **54.9%**。大位移组新流程按当前距离规则直接进入完整搜索。若让同一个新检测器先试局部，大位移组中位耗时为 **32.7 ms**，P90 为 **80.7 ms**，其中 11/23 个单位进入完整回退。直接完整的中位耗时为 37.6 ms，P90 为 60.4 ms。

## 两套流程都成功走局部的配对样本

| 输入条件 | 配对单位数 | 原流程中位／P90（ms） | 新流程中位／P90（ms） |
| --- | ---: | ---: | ---: |
| 旧框平移短边 6% | 12 | 17.3／22.1 | 20.4／32.0 |

只在两套流程均接纳局部结果的同一单位上计算本表。小位移下，共用 Beam 在这 12 个单位上耗时略高。纳入全组后，原流程 11 个单位发生完整回退，新流程有 3 个，所以全组中位耗时下降。

## 实验设置

- 数据取自 `frame_5b58dfca4481` 视频第 162000 帧的 23 个有效单位。固定同一原图、mask、标定和已登记托盘尺寸，按此前决定排除 B2.1。
- 直接完整搜索不传旧框。其余三组用原流程完整搜索的接纳框，按短边比例在标定桌面平面偏移，并在指定组绕中心旋转。65% 组模拟超过 50% 质心距离门槛时的路由。
- AMD Ryzen 7 9850X3D，Python 3.13.16，OpenCV 5.0.0，NumPy 2.5.2。OpenCV、OpenBLAS 和 OMP 各限制为单线程。每个单位、场景和版本预热一次，计时 5 次，版本执行顺序用固定随机种子打散。
- 计时范围是 `fit_tray`，包含 ROI、LSD、搜索、精调及该调用中的完整回退。模型推理、视频解码、稳定复用和重拟合路由的质心比较耗时在计时之外。
- 先对每单位的重复测量取中位数，再报告跨单位中位数和 P90。统计单位是在同一帧中各托盘的配对结果。四角差异以旧版完整拟合为参照，适用于说明结果变化。结论限于这组受控输入，真实直播速度和实体托盘误差需要单独测量。

## English text for the thesis

We compared the original tray fitter with shared directional Chamfer beam search on 23 trays from one archived video frame, using a common 70% mask coverage gate and five timed runs per tray and condition. For fitting from scratch, the median CPU time per tray fell from 85.6 to 38.6 ms (54.9% lower). For a translation of 6% of the short side, the corresponding times were 32.8 and 25.0 ms. For an 18% translation combined with an 8° rotation, they were 104.1 and 28.7 ms. For a 65% translation, the deployed route entered full search directly and took 37.6 ms compared with 100.8 ms for the original fitter. The workload uses fixed segmentation masks and controlled perturbations of the previous tray pose.
